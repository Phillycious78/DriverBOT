import React, { useState } from 'react';
import { CastMember } from '../types';
import { AlertTriangle } from 'lucide-react';
import { Footer } from './Footer';

interface DelayReportProps {
  selectedCastMembers: CastMember[];
  onReportNow: (delayedCastMembers: CastMember[]) => void;
  onBack: () => void;
  onAdminClick: () => void;
}

export const DelayReport: React.FC<DelayReportProps> = ({
  selectedCastMembers,
  onReportNow,
  onBack,
  onAdminClick,
}) => {
  const [delayedMembers, setDelayedMembers] = useState<CastMember[]>([]);

  const toggleDelayedMember = (member: CastMember) => {
    setDelayedMembers(prev => {
      const isAlreadySelected = prev.some(m => m.id === member.id);
      if (isAlreadySelected) {
        return prev.filter(m => m.id !== member.id);
      } else {
        return [...prev, member];
      }
    });
  };

  const isDelayed = (member: CastMember) =>
    delayedMembers.some(m => m.id === member.id);

  return (
    <div className="min-h-screen p-4 pt-2 pb-20" style={{ backgroundColor: '#7ed957' }}>
      <div className="max-w-md mx-auto">
        <div className="text-center mb-8">
          <div className="w-20 h-20 bg-warning-500 rounded-full flex items-center justify-center mx-auto mb-4">
            <AlertTriangle className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-gray-800 mb-2">Report Delay</h1>
          <p className="text-gray-600">Select which cast members are delayed</p>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg mb-6">
          <h3 className="text-lg font-semibold text-gray-700 mb-4">Cast Members:</h3>
          <div className="space-y-3">
            {selectedCastMembers.map((member) => (
              <button
                key={member.id}
                onClick={() => toggleDelayedMember(member)}
                className={`w-full p-4 rounded-lg text-left transition-all duration-200 ${
                  isDelayed(member)
                    ? 'bg-warning-100 border-2 border-warning-500 text-warning-800'
                    : 'bg-gray-50 hover:bg-gray-100 text-gray-700'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-medium">{member.name}</span>
                  {isDelayed(member) && (
                    <div className="w-6 h-6 bg-warning-500 rounded-full flex items-center justify-center">
                      <span className="text-white text-sm">✓</span>
                    </div>
                  )}
                </div>
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-4">
          <button
            onClick={() => onReportNow(delayedMembers)}
            disabled={delayedMembers.length === 0}
            className={`w-full py-4 rounded-xl text-lg font-semibold transition-colors shadow-lg ${
              delayedMembers.length > 0
                ? 'bg-warning-500 text-white hover:bg-warning-600'
                : 'bg-gray-300 text-gray-500 cursor-not-allowed'
            }`}
          >
            Report Now ({delayedMembers.length} delayed)
          </button>

          <button
            onClick={onBack}
            className="w-full py-4 rounded-xl text-lg font-semibold bg-gray-200 text-gray-700 hover:bg-gray-300 transition-colors"
          >
            Back
          </button>
        </div>
      </div>
      <Footer onAdminClick={onAdminClick} />
    </div>
  );
};