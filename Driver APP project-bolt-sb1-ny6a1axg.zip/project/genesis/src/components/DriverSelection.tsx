import React from 'react';
import { Driver } from '../types';
import { useData } from '../contexts/DataContext';
import { ChevronDown, ChevronUp, Check, Edit2 } from 'lucide-react';
import { Footer } from './Footer';

interface DriverSelectionProps {
  selectedDriver: Driver | null;
  onDriverSelect: (driver: Driver) => void;
  onAdminClick: () => void;
}

export const DriverSelection: React.FC<DriverSelectionProps> = ({
  selectedDriver,
  onDriverSelect,
  onAdminClick,
}) => {
  const { drivers } = useData();
  const [isDropdownOpen, setIsDropdownOpen] = React.useState(false);
  const [showChangeOption, setShowChangeOption] = React.useState(false);

  const handleDriverSelect = (driver: Driver) => {
    onDriverSelect(driver);
    setIsDropdownOpen(false);
    setShowChangeOption(true);
  };

  const handleChangeDriver = () => {
    setShowChangeOption(false);
    setIsDropdownOpen(true);
  };

  return (
    <div className="min-h-screen p-4 pt-2 pb-20" style={{ backgroundColor: '#7ed957' }}>
      <div className="max-w-md mx-auto">
        <div className="text-center mb-4">
          <div className="w-40 h-40 mx-auto mb-2 flex items-center justify-center">
            <img 
              src="/J.png" 
              alt="Cast PickUp Bot Logo" 
              className="w-full h-full object-contain"
            />
          </div>
          <h1 className="text-2xl font-bold text-gray-800 mb-1">Cast PickUp Bot</h1>
          <p className="text-gray-600">
            {selectedDriver ? 'Driver selected' : 'Select your name to continue'}
          </p>
        </div>

        {!selectedDriver || !showChangeOption ? (
          /* Dropdown Selection */
          <div className="relative mb-4">
            <button
              onClick={() => setIsDropdownOpen(!isDropdownOpen)}
              className="w-full bg-white rounded-xl p-4 flex items-center justify-between shadow-md hover:shadow-lg transition-shadow"
            >
              <span className="text-lg font-medium text-gray-700">
                {selectedDriver ? selectedDriver.name : 'Select your name...'}
              </span>
              {isDropdownOpen ? (
                <ChevronUp className="w-6 h-6 text-gray-500" />
              ) : (
                <ChevronDown className="w-6 h-6 text-gray-500" />
              )}
            </button>

            {isDropdownOpen && (
              <div className="absolute top-full left-0 right-0 mt-2 bg-white rounded-xl shadow-xl border border-gray-100 overflow-y-auto z-10" style={{ maxHeight: '192px' }}>
                {drivers.map((driver) => (
                  <button
                    key={driver.id}
                    onClick={() => handleDriverSelect(driver)}
                    className={`w-full p-4 text-left flex items-center justify-between hover:bg-gray-50 transition-colors border-b border-gray-50 last:border-b-0 ${
                      selectedDriver?.id === driver.id ? 'bg-blue-50' : ''
                    }`}
                  >
                    <span
                      className={`font-medium ${
                        selectedDriver?.id === driver.id ? 'text-blue-600' : 'text-gray-700'
                      }`}
                    >
                      {driver.name}
                    </span>
                    {selectedDriver?.id === driver.id && (
                      <Check className="w-5 h-5 text-blue-600" />
                    )}
                  </button>
                ))}
              </div>
            )}
          </div>
        ) : (
          /* Selected Driver Display with Change Option */
          <div className="space-y-4">
            <div className="bg-white rounded-xl p-6 shadow-lg">
              <div className="text-center">
                <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Check className="w-8 h-8 text-primary-600" />
                </div>
                <p className="text-gray-600 mb-2">Selected Driver:</p>
                <p className="text-2xl font-bold text-primary-600 mb-4">{selectedDriver.name}</p>
                
                <div className="flex justify-center space-x-3">
                  <button
                    onClick={handleChangeDriver}
                    className="bg-gray-100 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-200 transition-colors flex items-center space-x-2"
                  >
                    <Edit2 className="w-4 h-4" />
                    <span>Change</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
      <Footer onAdminClick={onAdminClick} />
    </div>
  );
};