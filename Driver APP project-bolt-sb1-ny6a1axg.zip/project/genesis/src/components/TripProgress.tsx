import React from 'react';
import { Driver, CastMember } from '../types';
import { Clock, CheckCircle, ArrowLeft } from 'lucide-react';
import { Footer } from './Footer';

interface TripProgressProps {
  selectedDriver: Driver;
  selectedCastMembers: CastMember[];
  eta: { hours: number; minutes: number };
  onFiveMinWarning: () => void;
  onDropOff: () => void;
  onAdminClick: () => void;
  onGoBackToActions?: () => void;
}

export const TripProgress: React.FC<TripProgressProps> = ({
  selectedDriver,
  selectedCastMembers,
  eta,
  onFiveMinWarning,
  onDropOff,
  onAdminClick,
  onGoBackToActions,
}) => {
  return (
    <div className="min-h-screen p-4 pt-2 pb-20" style={{ backgroundColor: '#7ed957' }}>
      <div className="max-w-md mx-auto">
        {/* Back Button */}
        {onGoBackToActions && (
          <button
            onClick={onGoBackToActions}
            className="mb-4 flex items-center space-x-2 text-gray-600 hover:text-gray-800 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span className="text-sm font-medium">Back to Actions</span>
          </button>
        )}

        {/* Main Content Card */}
        <div className="bg-white rounded-3xl p-8 shadow-2xl">
          {/* Car Icon */}
          <div className="text-center mb-8">
            <div className="w-24 h-24 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <svg className="w-12 h-12 text-primary-600" fill="currentColor" viewBox="0 0 24 24">
                <path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.22.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.5 16c-.83 0-1.5-.67-1.5-1.5S5.67 13 6.5 13s1.5.67 1.5 1.5S7.33 16 6.5 16zm11 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zM5 11l1.5-4.5h11L19 11H5z"/>
              </svg>
            </div>
          </div>

          {/* Trip Status */}
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-gray-800 mb-2">TRIP IN PROGRESS</h1>
          </div>

          {/* Driver Info */}
          <div className="text-center mb-6">
            <div className="text-sm text-gray-500 mb-1">DRIVER</div>
            <div className="text-2xl font-bold text-gray-800">{selectedDriver.name}</div>
          </div>

          {/* Cast Members */}
          <div className="text-center mb-6">
            <div className="text-sm text-gray-500 mb-1">CAST MEMBERS</div>
            <div className="text-lg font-bold text-gray-800 max-w-xs mx-auto space-y-1">
              {selectedCastMembers.map((member, index) => (
                <div key={member.id} className="leading-tight">
                  {member.name}
                </div>
              ))}
            </div>
          </div>

          {/* ETA */}
          <div className="text-center mb-12">
            <div className="text-sm text-gray-500 mb-1">ETA</div>
            <div className="text-4xl font-bold text-gray-800">
              {eta.hours.toString().padStart(2, '0')}:{eta.minutes.toString().padStart(2, '0')}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="space-y-4">
            <button
              onClick={onFiveMinWarning}
              className="w-full bg-warning-500 text-white py-4 rounded-2xl text-lg font-semibold hover:bg-warning-600 transition-colors shadow-lg flex items-center justify-center space-x-3"
            >
              <Clock className="w-6 h-6" />
              <span>5 Minute Warning</span>
            </button>

            <button
              onClick={onDropOff}
              className="w-full bg-primary-500 text-white py-4 rounded-2xl text-lg font-semibold hover:bg-primary-600 transition-colors shadow-lg flex items-center justify-center space-x-3"
            >
              <CheckCircle className="w-6 h-6" />
              <span>Drop Off</span>
            </button>
          </div>
        </div>
      </div>
      <Footer onAdminClick={onAdminClick} />
    </div>
  );
};