import React, { useState, useEffect } from 'react';
import { Driver, CastMember, MessageTemplates, TelegramSettings } from '../types';
import { useData } from '../contexts/DataContext';
import { useTelegram } from '../hooks/useTelegram';
import { Settings, Users, MessageSquare, Send, Plus, Edit2, Trash2, Save, X, Eye, EyeOff, ArrowLeft, Home } from 'lucide-react';

interface AdminPanelProps {
  onClose: () => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({ onClose }) => {
  const [activeSection, setActiveSection] = useState<'overview' | 'drivers' | 'cast' | 'messages' | 'telegram'>('overview');
  const { 
    drivers, 
    castMembers, 
    messageTemplates, 
    telegramSettings,
    updateDrivers,
    updateCastMembers,
    updateMessageTemplates,
    updateTelegramSettings
  } = useData();
  const [editingDriver, setEditingDriver] = useState<Driver | null>(null);
  const [editingCast, setEditingCast] = useState<CastMember | null>(null);
  const [newDriverName, setNewDriverName] = useState('');
  const [newCastName, setNewCastName] = useState('');
  const [showToken, setShowToken] = useState(false);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved'>('idle');

  // Telegram testing
  const telegram = useTelegram();
  const [testResult, setTestResult] = useState<{ success: boolean; error?: string; botInfo?: any } | null>(null);

  // Save data to localStorage
  const saveData = () => {
    setSaveStatus('saving');
    // Data is already saved automatically through the context
    
    setTimeout(() => {
      setSaveStatus('saved');
      setTimeout(() => setSaveStatus('idle'), 2000);
    }, 500);
  };

  // Driver management
  const addDriver = () => {
    if (newDriverName.trim()) {
      const newDriver: Driver = {
        id: Date.now().toString(),
        name: newDriverName.trim()
      };
      updateDrivers([...drivers, newDriver]);
      setNewDriverName('');
    }
  };

  const updateDriver = (id: string, name: string) => {
    updateDrivers(drivers.map(d => d.id === id ? { ...d, name } : d));
    setEditingDriver(null);
  };

  const deleteDriver = (id: string) => {
    updateDrivers(drivers.filter(d => d.id !== id));
  };

  // Cast member management
  const addCastMember = () => {
    if (newCastName.trim()) {
      const newCast: CastMember = {
        id: Date.now().toString(),
        name: newCastName.trim()
      };
      updateCastMembers([...castMembers, newCast]);
      setNewCastName('');
    }
  };

  const updateCastMember = (id: string, name: string) => {
    updateCastMembers(castMembers.map(c => c.id === id ? { ...c, name } : c));
    setEditingCast(null);
  };

  const deleteCastMember = (id: string) => {
    updateCastMembers(castMembers.filter(c => c.id !== id));
  };

  // Test Telegram connection
  const handleTestConnection = async () => {
    const result = await telegram.testConnection();
    setTestResult(result);
  };

  const tabs = [
    { id: 'overview', label: 'Overview', icon: Home },
    { id: 'drivers', label: 'Drivers', icon: Users },
    { id: 'cast', label: 'Cast', icon: Users },
    { id: 'messages', label: 'Messages', icon: MessageSquare },
    { id: 'telegram', label: 'Telegram', icon: Send }
  ];

  const renderOverview = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Drivers Section */}
        <div 
          onClick={() => setActiveSection('drivers')}
          className="bg-white rounded-lg p-4 shadow hover:shadow-md transition-all duration-200 cursor-pointer border hover:border-blue-200"
        >
          <div className="flex items-center justify-between mb-3">
            <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
              <Users className="w-5 h-5 text-blue-600" />
            </div>
            <span className="text-xl font-bold text-gray-800">{drivers.length}</span>
          </div>
          <h3 className="text-lg font-semibold text-gray-800 mb-1">Drivers</h3>
          <p className="text-sm text-gray-600 mb-2">Manage driver list</p>
          <div className="text-blue-600 text-sm font-medium">Click to manage →</div>
        </div>

        {/* Cast Members Section */}
        <div 
          onClick={() => setActiveSection('cast')}
          className="bg-white rounded-lg p-4 shadow hover:shadow-md transition-all duration-200 cursor-pointer border hover:border-green-200"
        >
          <div className="flex items-center justify-between mb-3">
            <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
              <Users className="w-5 h-5 text-green-600" />
            </div>
            <span className="text-xl font-bold text-gray-800">{castMembers.length}</span>
          </div>
          <h3 className="text-lg font-semibold text-gray-800 mb-1">Cast Members</h3>
          <p className="text-sm text-gray-600 mb-2">Add and edit cast</p>
          <div className="text-green-600 text-sm font-medium">Click to manage →</div>
        </div>

        {/* Messages Section */}
        <div 
          onClick={() => setActiveSection('messages')}
          className="bg-white rounded-lg p-4 shadow hover:shadow-md transition-all duration-200 cursor-pointer border hover:border-purple-200"
        >
          <div className="flex items-center justify-between mb-3">
            <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
              <MessageSquare className="w-5 h-5 text-purple-600" />
            </div>
            <span className="text-xl font-bold text-gray-800">{Object.keys(messageTemplates).length}</span>
          </div>
          <h3 className="text-lg font-semibold text-gray-800 mb-1">Message Templates</h3>
          <p className="text-sm text-gray-600 mb-2">Customize notifications</p>
          <div className="text-purple-600 text-sm font-medium">Click to edit →</div>
        </div>

        {/* Telegram Section */}
        <div 
          onClick={() => setActiveSection('telegram')}
          className="bg-white rounded-lg p-4 shadow hover:shadow-md transition-all duration-200 cursor-pointer border hover:border-orange-200"
        >
          <div className="flex items-center justify-between mb-3">
            <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
              <Send className="w-5 h-5 text-orange-600" />
            </div>
            <div className={`w-3 h-3 rounded-full ${telegramSettings.token && telegramSettings.chatId ? 'bg-green-500' : 'bg-red-500'}`}></div>
          </div>
          <h3 className="text-lg font-semibold text-gray-800 mb-1">Telegram Bot</h3>
          <p className="text-sm text-gray-600 mb-2">Configure bot settings</p>
          <div className="text-orange-600 text-sm font-medium">Click to configure →</div>
        </div>
      </div>
    </div>
  );

  const renderDrivers = () => (
    <div className="space-y-4">
      <div className="bg-white rounded-lg p-4 shadow">
        <div className="flex items-center space-x-3 mb-4">
          <input
            type="text"
            value={newDriverName}
            onChange={(e) => setNewDriverName(e.target.value)}
            placeholder="Enter driver name"
            className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            onKeyPress={(e) => e.key === 'Enter' && addDriver()}
          />
          <button
            onClick={addDriver}
            className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 flex items-center space-x-2"
          >
            <Plus className="w-4 h-4" />
            <span>Add</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {drivers.map((driver) => (
            <div key={driver.id} className="bg-gray-50 rounded-lg p-3 hover:bg-gray-100 transition-colors">
              {editingDriver?.id === driver.id ? (
                <input
                  type="text"
                  defaultValue={driver.name}
                  className="w-full px-3 py-2 border border-gray-300 rounded mb-2"
                  onKeyPress={(e) => {
                    if (e.key === 'Enter') {
                      updateDriver(driver.id, (e.target as HTMLInputElement).value);
                    }
                  }}
                  onBlur={(e) => updateDriver(driver.id, e.target.value)}
                  autoFocus
                />
              ) : (
                <div className="font-medium text-gray-800 mb-2">{driver.name}</div>
              )}
              <div className="flex justify-end space-x-2">
                <button
                  onClick={() => setEditingDriver(driver)}
                  className="text-blue-500 hover:text-blue-700 p-1 hover:bg-blue-50 rounded transition-colors"
                >
                  <Edit2 className="w-4 h-4" />
                </button>
                <button
                  onClick={() => deleteDriver(driver.id)}
                  className="text-red-500 hover:text-red-700 p-1 hover:bg-red-50 rounded transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderCast = () => (
    <div className="space-y-4">
      <div className="bg-white rounded-lg p-4 shadow">
        <div className="flex items-center space-x-3 mb-4">
          <input
            type="text"
            value={newCastName}
            onChange={(e) => setNewCastName(e.target.value)}
            placeholder="Enter cast member name"
            className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
            onKeyPress={(e) => e.key === 'Enter' && addCastMember()}
          />
          <button
            onClick={addCastMember}
            className="bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600 flex items-center space-x-2"
          >
            <Plus className="w-4 h-4" />
            <span>Add</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {castMembers.map((cast) => (
            <div key={cast.id} className="bg-gray-50 rounded-lg p-3 hover:bg-gray-100 transition-colors">
              {editingCast?.id === cast.id ? (
                <input
                  type="text"
                  defaultValue={cast.name}
                  className="w-full px-3 py-2 border border-gray-300 rounded mb-2"
                  onKeyPress={(e) => {
                    if (e.key === 'Enter') {
                      updateCastMember(cast.id, (e.target as HTMLInputElement).value);
                    }
                  }}
                  onBlur={(e) => updateCastMember(cast.id, e.target.value)}
                  autoFocus
                />
              ) : (
                <div className="font-medium text-gray-800 mb-2">{cast.name}</div>
              )}
              <div className="flex justify-end space-x-2">
                <button
                  onClick={() => setEditingCast(cast)}
                  className="text-blue-500 hover:text-blue-700 p-1 hover:bg-blue-50 rounded transition-colors"
                >
                  <Edit2 className="w-4 h-4" />
                </button>
                <button
                  onClick={() => deleteCastMember(cast.id)}
                  className="text-red-500 hover:text-red-700 p-1 hover:bg-red-50 rounded transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderMessages = () => (
    <div className="space-y-4">
      <div className="bg-purple-50 border border-purple-200 rounded-lg p-3">
        <h4 className="font-medium text-purple-800 mb-2">Available Placeholders:</h4>
        <div className="flex flex-wrap gap-2 text-xs">
          <code className="bg-purple-100 text-purple-800 px-2 py-1 rounded">{'{driver}'}</code>
          <code className="bg-purple-100 text-purple-800 px-2 py-1 rounded">{'{castMembers}'}</code>
          <code className="bg-purple-100 text-purple-800 px-2 py-1 rounded">{'{delayedCastMembers}'}</code>
          <code className="bg-purple-100 text-purple-800 px-2 py-1 rounded">{'{eta}'}</code>
          <code className="bg-purple-100 text-purple-800 px-2 py-1 rounded">{'{time}'}</code>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {Object.entries(messageTemplates).map(([key, template]) => (
          <div key={key} className="bg-white rounded-lg p-4 shadow">
            <label className="block text-sm font-medium text-gray-700 mb-2 capitalize">
              {key.replace(/([A-Z])/g, ' $1').trim()}
            </label>
            <textarea
              value={template}
              onChange={(e) => updateMessageTemplates({
                ...messageTemplates,
                [key]: e.target.value
              })}
              rows={6}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent font-mono text-xs resize-none"
            />
          </div>
        ))}
      </div>
    </div>
  );

  const renderTelegram = () => (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
      <div className="bg-white rounded-lg p-4 shadow">
        <h3 className="text-lg font-medium text-gray-800 mb-4">Bot Settings</h3>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Bot Token
            </label>
            <div className="relative">
              <input
                type={showToken ? 'text' : 'password'}
                value={telegramSettings.token}
                onChange={(e) => updateTelegramSettings({
                  ...telegramSettings,
                  token: e.target.value
                })}
                placeholder="Enter your Telegram bot token"
                className="w-full px-3 py-2 pr-10 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
              />
              <button
                type="button"
                onClick={() => setShowToken(!showToken)}
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
              >
                {showToken ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Chat ID
            </label>
            <input
              type="text"
              value={telegramSettings.chatId}
              onChange={(e) => updateTelegramSettings({
                ...telegramSettings,
                chatId: e.target.value
              })}
              placeholder="Enter your Telegram chat ID"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
            />
          </div>

          <div className="space-y-4">
            <button
              onClick={handleTestConnection}
              disabled={telegram.isLoading || !telegramSettings.token}
              className={`w-full py-3 rounded-lg font-medium flex items-center justify-center space-x-2 transition-colors ${
                telegram.isLoading
                  ? 'bg-gray-400 text-white cursor-not-allowed'
                  : telegramSettings.token
                  ? 'bg-blue-500 text-white hover:bg-blue-600'
                  : 'bg-gray-300 text-gray-500 cursor-not-allowed'
              }`}
            >
              <Send className="w-4 h-4" />
              <span>{telegram.isLoading ? 'Testing...' : 'Test Connection'}</span>
            </button>

            {testResult && (
              <div className={`p-4 rounded-lg ${
                testResult.success ? 'bg-green-50 border border-green-200' : 'bg-red-50 border border-red-200'
              }`}>
                <div className={`font-medium ${testResult.success ? 'text-green-800' : 'text-red-800'}`}>
                  {testResult.success ? '✅ Connection Successful!' : '❌ Connection Failed'}
                </div>
                {testResult.success && testResult.botInfo && (
                  <div className="text-green-700 text-sm mt-2">
                    Bot: @{testResult.botInfo.username} ({testResult.botInfo.first_name})
                  </div>
                )}
                {!testResult.success && testResult.error && (
                  <div className="text-red-700 text-sm mt-2">
                    Error: {testResult.error}
                  </div>
                )}
              </div>
            )}
          </div>

          <div className="flex items-center space-x-2 pt-2">
            <div className={`w-3 h-3 rounded-full ${telegramSettings.token && telegramSettings.chatId ? 'bg-green-500' : 'bg-red-500'}`}></div>
            <span className={`text-sm font-medium ${telegramSettings.token && telegramSettings.chatId ? 'text-green-600' : 'text-red-600'}`}>
              {telegramSettings.token && telegramSettings.chatId ? 'Configuration Complete' : 'Configuration Required'}
            </span>
          </div>
        </div>
      </div>

      <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
        <h4 className="text-lg font-medium text-orange-800 mb-3">🔧 Setup Instructions</h4>
        <ol className="text-orange-700 space-y-2 list-decimal list-inside text-sm">
          <li>Create a bot by messaging <strong>@BotFather</strong> on Telegram</li>
          <li>Copy the bot token from BotFather</li>
          <li>Add your bot to the desired group/chat</li>
          <li>Send a message in the group, then visit (replace [TOKEN]):<br/>
            <code className="text-xs bg-orange-100 px-2 py-1 rounded mt-1 block break-all">
              https://api.telegram.org/bot[TOKEN]/getUpdates
            </code>
          </li>
          <li>Find your chat ID in the response</li>
          <li>Use the "Test Connection" button above to verify</li>
        </ol>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Compact Navigation */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-6xl mx-auto px-4 py-3">
          <div className="flex items-center justify-between mb-4">
            <button
              onClick={onClose}
              className="flex items-center space-x-2 text-gray-600 hover:text-gray-800 transition-colors bg-gray-100 hover:bg-gray-200 px-3 py-2 rounded-lg text-sm"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back to App</span>
            </button>
            
            <div className="flex items-center space-x-2">
              <Settings className="w-5 h-5 text-blue-600" />
              <span className="font-bold text-gray-800">Admin Panel</span>
            </div>
            
            <div></div>
          </div>
          
          {/* Overview Tab and Save Button */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => setActiveSection('overview')}
                className={`text-lg font-semibold transition-colors hover:text-blue-600 ${
                  activeSection === 'overview' ? 'text-gray-800' : 'text-blue-500'
                }`}
              >
                Overview
              </button>
            </div>
            
            <button
              onClick={saveData}
              disabled={saveStatus === 'saving'}
              className={`px-4 py-2 rounded-lg text-sm font-medium flex items-center space-x-2 transition-colors ${
                saveStatus === 'saved' 
                  ? 'bg-green-500 text-white' 
                  : saveStatus === 'saving'
                  ? 'bg-gray-400 text-white cursor-not-allowed'
                  : 'bg-blue-500 text-white hover:bg-blue-600'
              }`}
            >
              <Save className="w-4 h-4" />
              <span>
                {saveStatus === 'saving' ? 'Saving...' : saveStatus === 'saved' ? 'Saved!' : 'Save All Changes'}
              </span>
            </button>
          </div>
        </div>
      </div>

      {/* Compact Tabs */}

      {/* Content */}
      <div className="max-w-6xl mx-auto px-4 py-6">
        {activeSection === 'overview' && renderOverview()}
        {activeSection === 'drivers' && renderDrivers()}
        {activeSection === 'cast' && renderCast()}
        {activeSection === 'messages' && renderMessages()}
        {activeSection === 'telegram' && renderTelegram()}
      </div>
    </div>
  );
};