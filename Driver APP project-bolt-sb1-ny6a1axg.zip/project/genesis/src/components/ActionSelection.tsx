import React from 'react';
import { Driver, CastMember } from '../types';
import { Clock, Play, ArrowLeft } from 'lucide-react';
import { Footer } from './Footer';

interface ActionSelectionProps {
  selectedDriver: Driver;
  selectedCastMembers: CastMember[];
  eta: { hours: number; minutes: number };
  onReportDelay: () => void;
  onStartPickup: () => void;
  onGoBack: () => void;
  onAdminClick: () => void;
}

export const ActionSelection: React.FC<ActionSelectionProps> = ({
  selectedDriver,
  selectedCastMembers,
  eta,
  onReportDelay,
  onStartPickup,
  onGoBack,
  onAdminClick,
}) => {
  return (
    <div className="min-h-screen p-4 pt-2 pb-20" style={{ backgroundColor: '#7ed957' }}>
      <div className="max-w-md mx-auto">
        {/* Back Button */}
        <button
          onClick={onGoBack}
          className="mb-4 flex items-center space-x-2 text-gray-600 hover:text-gray-800 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          <span className="text-sm font-medium">Change ETA</span>
        </button>

        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-800 mb-2">Ready to Go</h1>
          <p className="text-gray-600">Choose your next action</p>
        </div>

        {/* Trip Summary */}
        <div className="bg-white rounded-xl p-6 shadow-lg mb-8">
          <div className="text-center">
            <div className="text-sm text-gray-600 mb-1">DRIVER</div>
            <div className="text-xl font-bold text-gray-800 mb-4">{selectedDriver.name}</div>
            
            <div className="text-sm text-gray-600 mb-1">CAST MEMBERS</div>
            <div className="text-lg font-semibold text-gray-800 mb-4">
              {selectedCastMembers.map(member => member.name).join(', ')}
            </div>
            
            <div className="text-sm text-gray-600 mb-1">ETA</div>
            <div className="text-2xl font-bold text-primary-600">
              {eta.hours.toString().padStart(2, '0')}:{eta.minutes.toString().padStart(2, '0')}
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="space-y-4">
          <button
            onClick={onReportDelay}
            className="w-full bg-warning-500 text-white py-4 rounded-xl text-lg font-semibold hover:bg-warning-600 transition-colors shadow-lg flex items-center justify-center space-x-3"
          >
            <Clock className="w-6 h-6" />
            <span>Report Delay</span>
          </button>

          <button
            onClick={onStartPickup}
            className="w-full bg-primary-500 text-white py-4 rounded-xl text-lg font-semibold hover:bg-primary-600 transition-colors shadow-lg flex items-center justify-center space-x-3"
          >
            <Play className="w-6 h-6" />
            <span>Start Pickup</span>
          </button>
        </div>
      </div>
      <Footer onAdminClick={onAdminClick} />
    </div>
  );
};