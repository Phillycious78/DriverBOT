interface TelegramMessage {
  text: string;
  parse_mode?: 'HTML' | 'Markdown';
}

interface TelegramResponse {
  ok: boolean;
  result?: any;
  error_code?: number;
  description?: string;
}

export class TelegramService {
  private botToken: string;
  private chatId: string;

  constructor(botToken: string, chatId: string) {
    this.botToken = botToken;
    this.chatId = chatId;
  }

  /**
   * Send a message to the configured Telegram chat
   */
  async sendMessage(text: string): Promise<{ success: boolean; error?: string }> {
    if (!this.botToken || !this.chatId) {
      return {
        success: false,
        error: 'Bot token or chat ID not configured'
      };
    }

    const url = `https://api.telegram.org/bot${this.botToken}/sendMessage`;
    
    const message: TelegramMessage = {
      text,
      parse_mode: 'HTML'
    };

    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          chat_id: this.chatId,
          ...message
        })
      });

      const data: TelegramResponse = await response.json();

      if (!response.ok || !data.ok) {
        return {
          success: false,
          error: data.description || `HTTP ${response.status}`
        };
      }

      return { success: true };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Network error'
      };
    }
  }

  /**
   * Test the bot configuration
   */
  async testConnection(): Promise<{ success: boolean; error?: string; botInfo?: any }> {
    if (!this.botToken) {
      return {
        success: false,
        error: 'Bot token not configured'
      };
    }

    const url = `https://api.telegram.org/bot${this.botToken}/getMe`;

    try {
      const response = await fetch(url);
      const data: TelegramResponse = await response.json();

      if (!response.ok || !data.ok) {
        return {
          success: false,
          error: data.description || `HTTP ${response.status}`
        };
      }

      return {
        success: true,
        botInfo: data.result
      };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Network error'
      };
    }
  }
}

/**
 * Create a TelegramService instance with current settings
 */
export const createTelegramService = (botToken: string, chatId: string): TelegramService => {
  return new TelegramService(botToken, chatId);
};