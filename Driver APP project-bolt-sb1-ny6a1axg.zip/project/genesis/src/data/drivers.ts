import { Driver } from '../types';

export const drivers: Driver[] = [
  { id: '1', name: 'Philly' },
  { id: '2', name: 'Morris' },
  { id: '3', name: 'Jojo' },
  { id: '4', name: 'AJ' },
  { id: '5', name: 'Ike' },
  { id: '6', name: 'Carsten' },
  { id: '7', name: 'Darija' },
];