export interface Driver {
  id: string;
  name: string;
}

export interface CastMember {
  id: string;
  name: string;
}

export interface AppState {
  currentStep: 'driver-selection' | 'cast-selection' | 'eta-selection' | 'action-selection' | 'trip-progress' | 'delay-report';
  selectedDriver: Driver | null;
  selectedCastMembers: CastMember[];
  eta: {
    hours: number;
    minutes: number;
  };
  tripStartTime: Date | null;
}

export interface TimePickerProps {
  hours: number;
  minutes: number;
  onTimeChange: (hours: number, minutes: number) => void;
}

export interface TelegramSettings {
  token: string;
  chatId: string;
}

export interface MessageTemplates {
  tripStarted: string;
  delayReported: string;
  fiveMinuteWarning: string;
  dropOffCompleted: string;
}