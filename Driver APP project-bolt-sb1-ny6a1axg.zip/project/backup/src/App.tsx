import React, { useState } from 'react';
import { AppState, Driver, CastMember } from './types';
import { DriverSelection } from './components/DriverSelection';
import { CastSelection } from './components/CastSelection';
import { ETASelection } from './components/ETASelection';
import { ActionSelection } from './components/ActionSelection';
import { TripProgress } from './components/TripProgress';
import { DelayReport } from './components/DelayReport';
import { NotificationPopup } from './components/NotificationPopup';
import { AdminPanel } from './components/AdminPanel';
import { AdminLogin } from './components/AdminLogin';

function App() {
  // Get current time for initial ETA
  const getCurrentTime = () => {
    // Get current time in Central European Time
    const now = new Date();
    const cetTime = new Date(now.toLocaleString("en-US", {timeZone: "Europe/Berlin"}));
    return {
      hours: cetTime.getHours(),
      minutes: cetTime.getMinutes()
    };
  };

  const [appState, setAppState] = useState<AppState>({
    currentStep: 'driver-selection',
    selectedDriver: null,
    selectedCastMembers: [],
    eta: getCurrentTime(),
    tripStartTime: null,
  });

  const [showAdminLogin, setShowAdminLogin] = useState(false);
  const [isAdminMode, setIsAdminMode] = useState(false);

  const [notification, setNotification] = useState<{
    message: string;
    isVisible: boolean;
  }>({
    message: '',
    isVisible: false,
  });

  const showNotification = (message: string) => {
    setNotification({
      message,
      isVisible: true,
    });
  };

  const hideNotification = () => {
    setNotification(prev => ({
      ...prev,
      isVisible: false,
    }));
  };
  const handleDriverSelect = (driver: Driver) => {
    setAppState(prev => ({
      ...prev,
      selectedDriver: driver,
      currentStep: 'cast-selection',
    }));
  };

  const handleGoBackToDriverSelection = () => {
    setAppState(prev => ({
      ...prev,
      currentStep: 'driver-selection',
    }));
  };

  const handleGoBackToCastSelection = () => {
    setAppState(prev => ({
      ...prev,
      currentStep: 'cast-selection',
    }));
  };

  const handleGoBackToETASelection = () => {
    setAppState(prev => ({
      ...prev,
      currentStep: 'eta-selection',
    }));
  };
  const handleCastMemberToggle = (castMember: CastMember) => {
    setAppState(prev => ({
      ...prev,
      selectedCastMembers: prev.selectedCastMembers.some(m => m.id === castMember.id)
        ? prev.selectedCastMembers.filter(m => m.id !== castMember.id)
        : [...prev.selectedCastMembers, castMember],
    }));
  };

  const handleTimeChange = (hours: number, minutes: number) => {
    setAppState(prev => ({
      ...prev,
      eta: { hours, minutes },
    }));
  };

  const handleETAConfirm = () => {
    setAppState(prev => ({
      ...prev,
      currentStep: 'action-selection',
    }));
  };

  const handleReportDelay = () => {
    setAppState(prev => ({
      ...prev,
      currentStep: 'delay-report',
    }));
  };

  const handleStartPickup = () => {
    const message = `🚗 TRIP STARTED

Driver: ${appState.selectedDriver?.name}
Cast Members: ${appState.selectedCastMembers.map(m => m.name).join(', ')}
ETA: ${appState.eta.hours.toString().padStart(2, '0')}:${appState.eta.minutes.toString().padStart(2, '0')}
Status: Trip started
Time: ${new Date().toLocaleTimeString()}`;

    showNotification(message);

    setAppState(prev => ({
      ...prev,
      currentStep: 'trip-progress',
      tripStartTime: new Date(),
    }));
    
    console.log('Starting pickup - would send to Telegram:', message);
  };

  const handleDelayReportSubmit = (delayedCastMembers: CastMember[]) => {
    const message = `⚠️ DELAY REPORTED

Driver: ${appState.selectedDriver?.name}
Delayed Cast Members: ${delayedCastMembers.map(m => m.name).join(', ')}
Time: ${new Date().toLocaleTimeString()}`;

    showNotification(message);
    
    console.log('Delay reported - would send to Telegram:', message);
    
    setAppState(prev => ({
      ...prev,
      currentStep: 'action-selection',
    }));
  };

  const handleFiveMinWarning = () => {
    const message = `⏰ 5 MINUTE WARNING

Driver: ${appState.selectedDriver?.name}
Cast Members: ${appState.selectedCastMembers.map(m => m.name).join(', ')}
Message: 5 minutes until arrival
Time: ${new Date().toLocaleTimeString()}`;

    showNotification(message);
    
    console.log('5-minute warning - would send to Telegram:', message);
  };

  const handleDropOff = () => {
    const message = `✅ DROP-OFF COMPLETED

Driver: ${appState.selectedDriver?.name}
Cast Members: ${appState.selectedCastMembers.map(m => m.name).join(', ')}
Message: Drop-off completed
Time: ${new Date().toLocaleTimeString()}`;

    showNotification(message);
    
    console.log('Drop-off completed - would send to Telegram:', message);
    
    // Reset app state
    setAppState({
      currentStep: 'driver-selection',
      selectedDriver: null,
      selectedCastMembers: [],
      eta: getCurrentTime(),
      tripStartTime: null,
    });
  };

  const handleAdminLogin = () => {
    setShowAdminLogin(false);
    setIsAdminMode(true);
  };

  const handleAdminClose = () => {
    setIsAdminMode(false);
  };

  // Admin access via keyboard shortcut (Ctrl/Cmd + Shift + A)
  React.useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key === 'A') {
        e.preventDefault();
        setShowAdminLogin(true);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // If in admin mode, show admin panel instead of main app
  if (isAdminMode) {
    return (
      <div className="App">
        <AdminPanel onClose={handleAdminClose} />
      </div>
    );
  }

  const renderCurrentStep = () => {
    switch (appState.currentStep) {
      case 'driver-selection':
        return (
          <DriverSelection
            selectedDriver={appState.selectedDriver}
            onDriverSelect={handleDriverSelect}
            onAdminClick={() => setShowAdminLogin(true)}
          />
        );
      
      case 'cast-selection':
        return (
          <CastSelection
            selectedCastMembers={appState.selectedCastMembers}
            onCastMemberToggle={handleCastMemberToggle}
            onNext={() => setAppState(prev => ({ ...prev, currentStep: 'eta-selection' }))}
            onGoBack={handleGoBackToDriverSelection}
            onAdminClick={() => setShowAdminLogin(true)}
          />
        );
      
      case 'eta-selection':
        return (
          <ETASelection
            hours={appState.eta.hours}
            minutes={appState.eta.minutes}
            onTimeChange={handleTimeChange}
            onConfirm={handleETAConfirm}
            onGoBack={handleGoBackToCastSelection}
            onAdminClick={() => setShowAdminLogin(true)}
          />
        );
      
      case 'action-selection':
        return (
          <ActionSelection
            selectedDriver={appState.selectedDriver!}
            selectedCastMembers={appState.selectedCastMembers}
            eta={appState.eta}
            onReportDelay={handleReportDelay}
            onStartPickup={handleStartPickup}
            onGoBack={handleGoBackToETASelection}
            onAdminClick={() => setShowAdminLogin(true)}
          />
        );
      
      case 'trip-progress':
        return (
          <TripProgress
            selectedDriver={appState.selectedDriver!}
            selectedCastMembers={appState.selectedCastMembers}
            eta={appState.eta}
            onFiveMinWarning={handleFiveMinWarning}
            onDropOff={handleDropOff}
            onAdminClick={() => setShowAdminLogin(true)}
          />
        );
      
      case 'delay-report':
        return (
          <DelayReport
            selectedCastMembers={appState.selectedCastMembers}
            onReportNow={handleDelayReportSubmit}
            onBack={() => setAppState(prev => ({ ...prev, currentStep: 'action-selection' }))}
            onAdminClick={() => setShowAdminLogin(true)}
          />
        );
      
      default:
        return null;
    }
  };

  return (
    <div className="App">
      {renderCurrentStep()}
      <NotificationPopup
        message={notification.message}
        isVisible={notification.isVisible}
        onClose={hideNotification}
      />
      
      {showAdminLogin && (
        <AdminLogin onLogin={handleAdminLogin} />
      )}
    </div>
  );
}

export default App;