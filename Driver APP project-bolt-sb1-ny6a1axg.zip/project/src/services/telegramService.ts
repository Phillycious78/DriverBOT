interface TelegramMessage {
  text: string;
  parse_mode?: 'HTML' | 'Markdown';
}

interface TelegramResponse {
  ok: boolean;
  result?: any;
  error_code?: number;
  description?: string;
}

export class TelegramService {
  private botToken: string;
  private chatId: string;

  constructor(botToken: string, chatId: string) {
    this.botToken = botToken;
    this.chatId = chatId;
  }

  /**
   * Send a message to the configured Telegram chat
   */
  async sendMessage(text: string): Promise<{ success: boolean; error?: string }> {
    if (!this.botToken || !this.chatId) {
      return {
        success: false,
        error: 'Bot token or chat ID not configured'
      };
    }

    // Add detailed logging for debugging
    console.log('Sending message to Telegram...');
    console.log('Chat ID:', this.chatId);
    console.log('Chat ID type:', typeof this.chatId);
    console.log('Message length:', text.length);

    const url = `https://api.telegram.org/bot${this.botToken}/sendMessage`;
    console.log('Request URL:', url);
    
    const message: TelegramMessage = {
      text,
      parse_mode: 'HTML'
    };

    const payload = {
      chat_id: this.chatId,
      ...message
    };
    
    console.log('Request payload:', payload);
    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload)
      });

      console.log('Response status:', response.status);
      console.log('Response ok:', response.ok);
      
      const data: TelegramResponse = await response.json();
      console.log('Response data:', data);

      if (!response.ok || !data.ok) {
        const errorMsg = data.description || `HTTP ${response.status}: ${response.statusText}`;
        console.error('Telegram API Error:', errorMsg);
        return {
          success: false,
          error: errorMsg
        };
      }

      console.log('Message sent successfully!');
      return { success: true };
    } catch (error) {
      console.error('Network error:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Network error'
      };
    }
  }

  /**
   * Test the bot configuration
   */
  async testConnection(): Promise<{ success: boolean; error?: string; botInfo?: any }> {
    if (!this.botToken) {
      return {
        success: false,
        error: 'Bot token not configured'
      };
    }

    // Add detailed logging for debugging
    console.log('Testing Telegram connection...');
    console.log('Bot token length:', this.botToken.length);
    console.log('Bot token starts with:', this.botToken.substring(0, 10) + '...');

    const url = `https://api.telegram.org/bot${this.botToken}/getMe`;
    console.log('Request URL:', url);

    try {
      const response = await fetch(url);
      console.log('Response status:', response.status);
      console.log('Response ok:', response.ok);
      
      const data: TelegramResponse = await response.json();
      console.log('Response data:', data);

      if (!response.ok || !data.ok) {
        const errorMsg = data.description || `HTTP ${response.status}: ${response.statusText}`;
        console.error('Telegram API Error:', errorMsg);
        return {
          success: false,
          error: errorMsg
        };
      }

      console.log('Connection successful!', data.result);
      return {
        success: true,
        botInfo: data.result
      };
    } catch (error) {
      console.error('Network error:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Network error'
      };
    }
  }
}

/**
 * Create a TelegramService instance with current settings
 */
export const createTelegramService = (botToken: string, chatId: string): TelegramService => {
  return new TelegramService(botToken, chatId);
};