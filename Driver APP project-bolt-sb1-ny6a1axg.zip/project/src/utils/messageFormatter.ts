import { Driver, CastMember, MessageTemplates } from '../types';

interface MessageData {
  driver?: Driver;
  castMembers?: CastMember[];
  delayedCastMembers?: CastMember[];
  eta?: { hours: number; minutes: number };
  time?: string;
}

/**
 * Format message templates with actual data
 */
export const formatMessage = (
  template: string,
  data: MessageData
): string => {
  let formattedMessage = template;

  // Replace placeholders with actual data
  if (data.driver) {
    formattedMessage = formattedMessage.replace(/{driver}/g, data.driver.name);
  }

  if (data.castMembers) {
    const castNames = data.castMembers.map(member => member.name).join(', ');
    formattedMessage = formattedMessage.replace(/{castMembers}/g, castNames);
  }

  if (data.delayedCastMembers) {
    const delayedNames = data.delayedCastMembers.map(member => member.name).join(', ');
    formattedMessage = formattedMessage.replace(/{delayedCastMembers}/g, delayedNames);
  }

  if (data.eta) {
    const etaString = `${data.eta.hours.toString().padStart(2, '0')}:${data.eta.minutes.toString().padStart(2, '0')}`;
    formattedMessage = formattedMessage.replace(/{eta}/g, etaString);
  }

  if (data.time) {
    formattedMessage = formattedMessage.replace(/{time}/g, data.time);
  }

  return formattedMessage;
};

/**
 * Get current time formatted for messages
 */
export const getCurrentTimeString = (): string => {
  const now = new Date();
  const cetTime = new Date(now.toLocaleString("en-US", {timeZone: "Europe/Berlin"}));
  return cetTime.toLocaleTimeString('de-DE', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
  });
};

/**
 * Create formatted messages for different actions
 */
export const createMessages = {
  tripStarted: (templates: MessageTemplates, driver: Driver, castMembers: CastMember[], eta: { hours: number; minutes: number }) => {
    return formatMessage(templates.tripStarted, {
      driver,
      castMembers,
      eta,
      time: getCurrentTimeString()
    });
  },

  delayReported: (templates: MessageTemplates, driver: Driver, delayedCastMembers: CastMember[]) => {
    return formatMessage(templates.delayReported, {
      driver,
      delayedCastMembers,
      time: getCurrentTimeString()
    });
  },

  fiveMinuteWarning: (templates: MessageTemplates, driver: Driver, castMembers: CastMember[]) => {
    return formatMessage(templates.fiveMinuteWarning, {
      driver,
      castMembers,
      time: getCurrentTimeString()
    });
  },

  dropOffCompleted: (templates: MessageTemplates, driver: Driver, castMembers: CastMember[]) => {
    return formatMessage(templates.dropOffCompleted, {
      driver,
      castMembers,
      time: getCurrentTimeString()
    });
  }
};