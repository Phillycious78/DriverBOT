import React, { useState, useEffect } from 'react';
import { Driver, CastMember, MessageTemplates, TelegramSettings, SideMission, LoginRecord } from '../types';
import { useData } from '../contexts/DataContext';
import { useAuth } from '../contexts/AuthContext';
import { useTelegram } from '../hooks/useTelegram';
import { ChatIdFinder } from './ChatIdFinder';
import { Settings, Users, MessageSquare, Send, Plus, Edit2, Trash2, Save, X, Eye, EyeOff, ArrowLeft, Home, MapPin, Clock, AlertCircle, User, ShoppingCart, Calendar, Download } from 'lucide-react';

interface AdminPanelProps {
  onClose: () => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({ onClose }) => {
  const [activeSection, setActiveSection] = useState<'overview' | 'drivers' | 'cast' | 'messages' | 'telegram' | 'missions' | 'timetracking'>('overview');
  const { 
    drivers, 
    castMembers, 
    messageTemplates, 
    telegramSettings,
    sideMissions,
    updateDrivers,
    updateCastMembers,
    updateMessageTemplates,
    updateTelegramSettings,
    updateSideMissions
  } = useData();
  const { loginRecords } = useAuth();
  const [editingDriver, setEditingDriver] = useState<Driver | null>(null);
  const [editingCast, setEditingCast] = useState<CastMember | null>(null);
  const [newDriverName, setNewDriverName] = useState('');
  const [newCastName, setNewCastName] = useState('');
  const [newMissionTitle, setNewMissionTitle] = useState('');
  const [newMissionDescription, setNewMissionDescription] = useState('');
  const [newMissionLocation, setNewMissionLocation] = useState('');
  const [newMissionPriority, setNewMissionPriority] = useState<'low' | 'medium' | 'high'>('medium');
  const [newMissionDuration, setNewMissionDuration] = useState('');
  const [showToken, setShowToken] = useState(false);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved'>('idle');

  // Time tracking state
  const [selectedDate, setSelectedDate] = useState(() => {
    const today = new Date();
    return today.toISOString().split('T')[0]; // YYYY-MM-DD format
  });

  // Telegram testing
  const telegram = useTelegram();
  const [testResult, setTestResult] = useState<{ success: boolean; error?: string; botInfo?: any } | null>(null);

  // Save data to localStorage
  const saveData = () => {
    setSaveStatus('saving');
    // Data is already saved automatically through the context
    
    setTimeout(() => {
      setSaveStatus('saved');
      setTimeout(() => setSaveStatus('idle'), 2000);
    }, 500);
  };

  // Driver management
  const addDriver = () => {
    if (newDriverName.trim()) {
      const newDriver: Driver = {
        id: Date.now().toString(),
        name: newDriverName.trim()
      };
      updateDrivers([...drivers, newDriver]);
      setNewDriverName('');
    }
  };

  const updateDriver = (id: string, name: string) => {
    updateDrivers(drivers.map(d => d.id === id ? { ...d, name } : d));
    setEditingDriver(null);
  };

  const deleteDriver = (id: string) => {
    updateDrivers(drivers.filter(d => d.id !== id));
  };

  // Cast member management
  const addCastMember = () => {
    if (newCastName.trim()) {
      const newCast: CastMember = {
        id: Date.now().toString(),
        name: newCastName.trim()
      };
      updateCastMembers([...castMembers, newCast]);
      setNewCastName('');
    }
  };

  const updateCastMember = (id: string, name: string) => {
    updateCastMembers(castMembers.map(c => c.id === id ? { ...c, name } : c));
    setEditingCast(null);
  };

  const deleteCastMember = (id: string) => {
    updateCastMembers(castMembers.filter(c => c.id !== id));
  };

  // Mission management
  const addMission = () => {
    if (newMissionTitle.trim() && newMissionDescription.trim() && newMissionLocation.trim() && newMissionDuration.trim()) {
      const newMission: SideMission = {
        id: Date.now().toString(),
        title: newMissionTitle.trim(),
        description: newMissionDescription.trim(),
        location: newMissionLocation.trim(),
        priority: newMissionPriority,
        estimatedDuration: newMissionDuration.trim(),
        status: 'available',
        createdAt: new Date()
      };
      updateSideMissions([...sideMissions, newMission]);
      setNewMissionTitle('');
      setNewMissionDescription('');
      setNewMissionLocation('');
      setNewMissionPriority('medium');
      setNewMissionDuration('');
    }
  };

  const deleteMission = (id: string) => {
    updateSideMissions(sideMissions.filter(m => m.id !== id));
  };

  const completeMission = (id: string) => {
    updateSideMissions(sideMissions.map(m => 
      m.id === id ? { ...m, status: 'completed' as const } : m
    ));
  };

  const resetMission = (id: string) => {
    updateSideMissions(sideMissions.map(m => 
      m.id === id ? { ...m, status: 'available' as const, assignedDriver: undefined } : m
    ));
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-800 border-red-200';
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'low': return 'bg-green-100 text-green-800 border-green-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'available': return 'bg-blue-100 text-blue-800';
      case 'assigned': return 'bg-orange-100 text-orange-800';
      case 'completed': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getDriverName = (driverId: string) => {
    const driver = drivers.find(d => d.id === driverId);
    return driver ? driver.name : 'Unknown Driver';
  };

  // Time tracking functions
  const getRecordsForDate = (date: string) => {
    return loginRecords.filter(record => record.date === date);
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', { 
      hour: '2-digit', 
      minute: '2-digit',
      hour12: true 
    });
  };

  const formatDuration = (loginTime: Date, logoutTime?: Date) => {
    const endTime = logoutTime || new Date();
    const durationMs = endTime.getTime() - loginTime.getTime();
    const hours = Math.floor(durationMs / (1000 * 60 * 60));
    const minutes = Math.floor((durationMs % (1000 * 60 * 60)) / (1000 * 60));
    return `${hours}h ${minutes}m`;
  };

  const exportTimeData = () => {
    const records = getRecordsForDate(selectedDate);
    if (records.length === 0) {
      alert('No data to export for this date');
      return;
    }

    const csvContent = [
      ['Driver Name', 'Login Time', 'Logout Time', 'Duration', 'Status'].join(','),
      ...records.map(record => [
        record.driverName,
        formatTime(record.loginTime),
        record.logoutTime ? formatTime(record.logoutTime) : 'Still logged in',
        formatDuration(record.loginTime, record.logoutTime),
        record.logoutTime ? 'Completed' : 'Active'
      ].join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `driver-timesheet-${selectedDate}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  const getTotalHoursForDate = (date: string) => {
    const records = getRecordsForDate(date);
    let totalMs = 0;
    
    records.forEach(record => {
      const endTime = record.logoutTime || new Date();
      totalMs += endTime.getTime() - record.loginTime.getTime();
    });
    
    const hours = Math.floor(totalMs / (1000 * 60 * 60));
    const minutes = Math.floor((totalMs % (1000 * 60 * 60)) / (1000 * 60));
    return `${hours}h ${minutes}m`;
  };

  // Test Telegram connection
  const handleTestConnection = async () => {
    const result = await telegram.testConnection();
    setTestResult(result);
  };

  const tabs = [
    { id: 'overview', label: 'Overview', icon: Home },
    { id: 'drivers', label: 'Drivers', icon: Users },
    { id: 'cast', label: 'Cast', icon: Users },
    { id: 'messages', label: 'Messages', icon: MessageSquare },
    { id: 'telegram', label: 'Telegram', icon: Send },
    { id: 'missions', label: 'Side Missions', icon: ShoppingCart },
    { id: 'timetracking', label: 'Time Tracking', icon: Calendar }
  ];

  const renderOverview = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Drivers Section */}
        <div 
          onClick={() => setActiveSection('drivers')}
          className="bg-white rounded-lg p-4 shadow hover:shadow-md transition-all duration-200 cursor-pointer border hover:border-blue-200"
        >
          <div className="flex items-center justify-between mb-3">
            <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
              <Users className="w-5 h-5 text-blue-600" />
            </div>
            <span className="text-xl font-bold text-gray-800">{drivers.length}</span>
          </div>
          <h3 className="text-lg font-semibold text-gray-800 mb-1">Drivers</h3>
          <p className="text-sm text-gray-600 mb-2">Manage driver list</p>
          <div className="text-blue-600 text-sm font-medium">Click to manage →</div>
        </div>

        {/* Cast Members Section */}
        <div 
          onClick={() => setActiveSection('cast')}
          className="bg-white rounded-lg p-4 shadow hover:shadow-md transition-all duration-200 cursor-pointer border hover:border-green-200"
        >
          <div className="flex items-center justify-between mb-3">
            <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
              <Users className="w-5 h-5 text-green-600" />
            </div>
            <span className="text-xl font-bold text-gray-800">{castMembers.length}</span>
          </div>
          <h3 className="text-lg font-semibold text-gray-800 mb-1">Cast Members</h3>
          <p className="text-sm text-gray-600 mb-2">Add and edit cast</p>
          <div className="text-green-600 text-sm font-medium">Click to manage →</div>
        </div>

        {/* Messages Section */}
        <div 
          onClick={() => setActiveSection('messages')}
          className="bg-white rounded-lg p-4 shadow hover:shadow-md transition-all duration-200 cursor-pointer border hover:border-purple-200"
        >
          <div className="flex items-center justify-between mb-3">
            <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
              <MessageSquare className="w-5 h-5 text-purple-600" />
            </div>
            <span className="text-xl font-bold text-gray-800">{Object.keys(messageTemplates).length}</span>
          </div>
          <h3 className="text-lg font-semibold text-gray-800 mb-1">Message Templates</h3>
          <p className="text-sm text-gray-600 mb-2">Customize notifications</p>
          <div className="text-purple-600 text-sm font-medium">Click to edit →</div>
        </div>

        {/* Telegram Section */}
        <div 
          onClick={() => setActiveSection('telegram')}
          className="bg-white rounded-lg p-4 shadow hover:shadow-md transition-all duration-200 cursor-pointer border hover:border-orange-200"
        >
          <div className="flex items-center justify-between mb-3">
            <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
              <Send className="w-5 h-5 text-orange-600" />
            </div>
            <div className={`w-3 h-3 rounded-full ${telegramSettings.token && telegramSettings.chatId ? 'bg-green-500' : 'bg-red-500'}`}></div>
          </div>
          <h3 className="text-lg font-semibold text-gray-800 mb-1">Telegram Bot</h3>
          <p className="text-sm text-gray-600 mb-2">Configure bot settings</p>
          <div className="text-orange-600 text-sm font-medium">Click to configure →</div>
        </div>

        {/* Side Missions Section */}
        <div 
          onClick={() => setActiveSection('missions')}
          className="bg-white rounded-lg p-4 shadow hover:shadow-md transition-all duration-200 cursor-pointer border hover:border-indigo-200"
        >
          <div className="flex items-center justify-between mb-3">
            <div className="w-10 h-10 bg-indigo-100 rounded-lg flex items-center justify-center">
              <ShoppingCart className="w-5 h-5 text-indigo-600" />
            </div>
            <span className="text-xl font-bold text-gray-800">{sideMissions.length}</span>
          </div>
          <h3 className="text-lg font-semibold text-gray-800 mb-1">Side Missions</h3>
          <p className="text-sm text-gray-600 mb-2">Manage additional tasks</p>
          <div className="text-indigo-600 text-sm font-medium">Click to manage →</div>
        </div>

        {/* Time Tracking Section */}
        <div 
          onClick={() => setActiveSection('timetracking')}
          className="bg-white rounded-lg p-4 shadow hover:shadow-md transition-all duration-200 cursor-pointer border hover:border-teal-200"
        >
          <div className="flex items-center justify-between mb-3">
            <div className="w-10 h-10 bg-teal-100 rounded-lg flex items-center justify-center">
              <Calendar className="w-5 h-5 text-teal-600" />
            </div>
            <span className="text-xl font-bold text-gray-800">{getRecordsForDate(selectedDate).length}</span>
          </div>
          <h3 className="text-lg font-semibold text-gray-800 mb-1">Time Tracking</h3>
          <p className="text-sm text-gray-600 mb-2">Driver login/logout times</p>
          <div className="text-teal-600 text-sm font-medium">Click to view →</div>
        </div>
      </div>
    </div>
  );

  const renderDrivers = () => (
    <div className="space-y-4">
      <div className="bg-white rounded-lg p-4 shadow">
        <h3 className="text-lg font-medium text-gray-800 mb-4">Manage Drivers</h3>
        <div className="flex items-center space-x-3 mb-4">
          <input
            type="text"
            value={newDriverName}
            onChange={(e) => setNewDriverName(e.target.value)}
            placeholder="Enter driver name"
            className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            onKeyPress={(e) => e.key === 'Enter' && addDriver()}
          />
          <button
            onClick={addDriver}
            className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 flex items-center space-x-2"
          >
            <Plus className="w-4 h-4" />
            <span>Add</span>
          </button>
        </div>

        <div className="space-y-3">
          {drivers.map((driver) => (
            <div key={driver.id} className="bg-gray-50 rounded-lg p-4 hover:bg-gray-100 transition-colors">
              {editingDriver?.id === driver.id ? (
                <input
                  type="text"
                  defaultValue={driver.name}
                  className="w-full px-3 py-2 border border-gray-300 rounded mb-2"
                  onKeyPress={(e) => {
                    if (e.key === 'Enter') {
                      updateDriver(driver.id, (e.target as HTMLInputElement).value);
                    }
                  }}
                  onBlur={(e) => updateDriver(driver.id, e.target.value)}
                  autoFocus
                />
              ) : (
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-medium text-gray-800">{driver.name}</div>
                    <div className="text-sm text-gray-500">Username: {driver.username || driver.name}</div>
                  </div>
                  <div className="flex space-x-2">
                    <button
                      onClick={() => setEditingDriver(driver)}
                      className="text-blue-500 hover:text-blue-700 p-2 hover:bg-blue-50 rounded transition-colors"
                      title="Edit driver"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => deleteDriver(driver.id)}
                      className="text-red-500 hover:text-red-700 p-2 hover:bg-red-50 rounded transition-colors"
                      title="Delete driver"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              )}
            </div>
          ))}
          {drivers.length === 0 && (
            <div className="text-center py-8 text-gray-500">
              <Users className="w-12 h-12 mx-auto mb-2 opacity-50" />
              <p>No drivers added yet</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );

  const renderCast = () => (
    <div className="space-y-4">
      <div className="bg-white rounded-lg p-4 shadow">
        <h3 className="text-lg font-medium text-gray-800 mb-4">Manage Cast Members</h3>
        <div className="flex items-center space-x-3 mb-4">
          <input
            type="text"
            value={newCastName}
            onChange={(e) => setNewCastName(e.target.value)}
            placeholder="Enter cast member name"
            className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
            onKeyPress={(e) => e.key === 'Enter' && addCastMember()}
          />
          <button
            onClick={addCastMember}
            className="bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600 flex items-center space-x-2"
          >
            <Plus className="w-4 h-4" />
            <span>Add</span>
          </button>
        </div>

        <div className="space-y-3">
          {castMembers.map((cast) => (
            <div key={cast.id} className="bg-gray-50 rounded-lg p-4 hover:bg-gray-100 transition-colors">
              {editingCast?.id === cast.id ? (
                <input
                  type="text"
                  defaultValue={cast.name}
                  className="w-full px-3 py-2 border border-gray-300 rounded mb-2"
                  onKeyPress={(e) => {
                    if (e.key === 'Enter') {
                      updateCastMember(cast.id, (e.target as HTMLInputElement).value);
                    }
                  }}
                  onBlur={(e) => updateCastMember(cast.id, e.target.value)}
                  autoFocus
                />
              ) : (
                <div className="flex items-center justify-between">
                  <div className="font-medium text-gray-800">{cast.name}</div>
                  <div className="flex space-x-2">
                    <button
                      onClick={() => setEditingCast(cast)}
                      className="text-blue-500 hover:text-blue-700 p-2 hover:bg-blue-50 rounded transition-colors"
                      title="Edit cast member"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => deleteCastMember(cast.id)}
                      className="text-red-500 hover:text-red-700 p-2 hover:bg-red-50 rounded transition-colors"
                      title="Delete cast member"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              )}
            </div>
          ))}
          {castMembers.length === 0 && (
            <div className="text-center py-8 text-gray-500">
              <Users className="w-12 h-12 mx-auto mb-2 opacity-50" />
              <p>No cast members added yet</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );

  const renderMessages = () => (
    <div className="space-y-4">
      <div className="bg-purple-50 border border-purple-200 rounded-lg p-3">
        <h4 className="font-medium text-purple-800 mb-2">Available Placeholders:</h4>
        <div className="flex flex-wrap gap-2 text-xs">
          <code className="bg-purple-100 text-purple-800 px-2 py-1 rounded">{'{driver}'}</code>
          <code className="bg-purple-100 text-purple-800 px-2 py-1 rounded">{'{castMembers}'}</code>
          <code className="bg-purple-100 text-purple-800 px-2 py-1 rounded">{'{delayedCastMembers}'}</code>
          <code className="bg-purple-100 text-purple-800 px-2 py-1 rounded">{'{eta}'}</code>
          <code className="bg-purple-100 text-purple-800 px-2 py-1 rounded">{'{time}'}</code>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {Object.entries(messageTemplates).map(([key, template]) => (
          <div key={key} className="bg-white rounded-lg p-4 shadow">
            <label className="block text-sm font-medium text-gray-700 mb-2 capitalize">
              {key.replace(/([A-Z])/g, ' $1').trim()}
            </label>
            <textarea
              value={template}
              onChange={(e) => updateMessageTemplates({
                ...messageTemplates,
                [key]: e.target.value
              })}
              rows={6}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent font-mono text-xs resize-none"
            />
          </div>
        ))}
      </div>
    </div>
  );

  const renderMissions = () => (
    <div className="space-y-4">
      <div className="bg-white rounded-lg p-4 shadow">
        <h3 className="text-lg font-medium text-gray-800 mb-4">Add New Mission</h3>
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <input
              type="text"
              value={newMissionTitle}
              onChange={(e) => setNewMissionTitle(e.target.value)}
              placeholder="Mission title"
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
            />
            <select
              value={newMissionPriority}
              onChange={(e) => setNewMissionPriority(e.target.value as 'low' | 'medium' | 'high')}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
            >
              <option value="low">Low Priority</option>
              <option value="medium">Medium Priority</option>
              <option value="high">High Priority</option>
            </select>
          </div>
          <textarea
            value={newMissionDescription}
            onChange={(e) => setNewMissionDescription(e.target.value)}
            placeholder="Mission description"
            rows={3}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
          />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <input
              type="text"
              value={newMissionLocation}
              onChange={(e) => setNewMissionLocation(e.target.value)}
              placeholder="Location (e.g., Studio A → Location B)"
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
            />
            <input
              type="text"
              value={newMissionDuration}
              onChange={(e) => setNewMissionDuration(e.target.value)}
              placeholder="Estimated duration (e.g., 30 minutes)"
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
            />
          </div>
          <button
            onClick={addMission}
            className="bg-indigo-500 text-white px-4 py-2 rounded-lg hover:bg-indigo-600 flex items-center space-x-2"
          >
            <Plus className="w-4 h-4" />
            <span>Add Mission</span>
          </button>
        </div>
      </div>

      <div className="bg-white rounded-lg p-4 shadow">
        <h3 className="text-lg font-medium text-gray-800 mb-4">Current Missions</h3>
        <div className="space-y-3">
          {sideMissions.map((mission) => (
            <div key={mission.id} className="bg-gray-50 rounded-lg p-4 hover:bg-gray-100 transition-colors">
              <div className="flex items-start justify-between mb-2">
                <div className="flex-1">
                  <div className="flex items-center space-x-2 mb-1">
                    <h4 className="font-medium text-gray-800">{mission.title}</h4>
                    <div className={`px-2 py-1 rounded-full text-xs font-medium border ${getPriorityColor(mission.priority)}`}>
                      {mission.priority}
                    </div>
                    <div className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(mission.status)}`}>
                      {mission.status}
                    </div>
                  </div>
                  <p className="text-sm text-gray-600 mb-2">{mission.description}</p>
                  <div className="flex items-center space-x-4 text-xs text-gray-500">
                    <div className="flex items-center space-x-1">
                      <MapPin className="w-3 h-3" />
                      <span>{mission.location}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Clock className="w-3 h-3" />
                      <span>{mission.estimatedDuration}</span>
                    </div>
                    {mission.assignedDriver && (
                      <div className="flex items-center space-x-1">
                        <User className="w-3 h-3" />
                        <span>{getDriverName(mission.assignedDriver)}</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
              
              {/* Action buttons below the assignment info */}
              <div className="flex justify-end space-x-2 mt-3">
                  {mission.status === 'assigned' && (
                    <button
                      onClick={() => completeMission(mission.id)}
                      className="bg-green-500 text-white px-3 py-1 rounded hover:bg-green-600 transition-colors text-xs font-medium"
                      title="Mark as completed"
                    >
                      Complete
                    </button>
                  )}
                  {mission.status !== 'available' && (
                    <button
                      onClick={() => resetMission(mission.id)}
                      className="bg-blue-500 text-white px-3 py-1 rounded hover:bg-blue-600 transition-colors text-xs font-medium"
                      title="Reset to available"
                    >
                      Reset
                    </button>
                  )}
                  <button
                    onClick={() => deleteMission(mission.id)}
                    className="bg-red-500 text-white px-3 py-1 rounded hover:bg-red-600 transition-colors text-xs font-medium"
                    title="Delete mission"
                  >
                    Trash
                  </button>
              </div>
            </div>
          ))}
          {sideMissions.length === 0 && (
            <div className="text-center py-8 text-gray-500">
              <MapPin className="w-12 h-12 mx-auto mb-2 opacity-50" />
              <p>No missions created yet</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );

  const renderTimeTracking = () => {
    const todayRecords = getRecordsForDate(selectedDate);
    const activeDrivers = todayRecords.filter(record => !record.logoutTime);
    
    return (
      <div className="space-y-6">
        {/* Date Selection and Export */}
        <div className="bg-white rounded-lg p-6 shadow">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
            <h3 className="text-lg font-medium text-gray-800">Time Tracking Dashboard</h3>
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="w-full sm:w-auto px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent"
              />
              <button
                onClick={exportTimeData}
                disabled={todayRecords.length === 0}
                className={`w-full sm:w-auto px-4 py-2 rounded-lg font-medium flex items-center justify-center space-x-2 transition-colors ${
                  todayRecords.length > 0
                    ? 'bg-teal-500 text-white hover:bg-teal-600'
                    : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                }`}
              >
                <Download className="w-4 h-4" />
                <span>Export CSV</span>
              </button>
            </div>
          </div>

          {/* Summary Stats */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 text-center sm:text-left">
              <div className="flex items-center justify-center sm:justify-start space-x-2 mb-2">
                <Users className="w-5 h-5 text-blue-600" />
                <span className="text-sm font-medium text-blue-800">Total Logins</span>
              </div>
              <div className="text-2xl font-bold text-blue-900">{todayRecords.length}</div>
            </div>
            
            <div className="bg-green-50 border border-green-200 rounded-lg p-4 text-center sm:text-left">
              <div className="flex items-center justify-center sm:justify-start space-x-2 mb-2">
                <Clock className="w-5 h-5 text-green-600" />
                <span className="text-sm font-medium text-green-800">Active Now</span>
              </div>
              <div className="text-2xl font-bold text-green-900">{activeDrivers.length}</div>
            </div>
            
            <div className="bg-purple-50 border border-purple-200 rounded-lg p-4 text-center sm:text-left">
              <div className="flex items-center justify-center sm:justify-start space-x-2 mb-2">
                <Calendar className="w-5 h-5 text-purple-600" />
                <span className="text-sm font-medium text-purple-800">Total Hours</span>
              </div>
              <div className="text-2xl font-bold text-purple-900">{getTotalHoursForDate(selectedDate)}</div>
            </div>
          </div>
        </div>

        {/* Time Records Table */}
        <div className="bg-white rounded-lg p-6 shadow">
          <h3 className="text-lg font-medium text-gray-800 mb-6">
            Driver Time Records - {new Date(selectedDate).toLocaleDateString('en-US', { 
              weekday: 'long', 
              year: 'numeric', 
              month: 'long', 
              day: 'numeric' 
            })}
          </h3>
          
          {todayRecords.length > 0 ? (
            <div className="overflow-x-auto -mx-6 px-6">
              <table className="w-full min-w-full">
                <thead>
                  <tr className="border-b border-gray-200">
                    <th className="text-left py-3 px-2 sm:px-4 font-medium text-gray-600 min-w-[120px]">Driver</th>
                    <th className="text-left py-3 px-2 sm:px-4 font-medium text-gray-600 min-w-[100px]">Login</th>
                    <th className="text-left py-3 px-2 sm:px-4 font-medium text-gray-600 min-w-[100px]">Logout</th>
                    <th className="text-left py-3 px-2 sm:px-4 font-medium text-gray-600 min-w-[80px]">Duration</th>
                    <th className="text-left py-3 px-2 sm:px-4 font-medium text-gray-600 min-w-[80px]">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {todayRecords.map((record) => (
                    <tr key={record.id} className="border-b border-gray-100 hover:bg-gray-50">
                      <td className="py-3 px-2 sm:px-4">
                        <div className="flex items-center space-x-2 min-w-0">
                          <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                            <User className="w-4 h-4 text-blue-600" />
                          </div>
                          <span className="font-medium text-gray-800 truncate">{record.driverName}</span>
                        </div>
                      </td>
                      <td className="py-3 px-2 sm:px-4 text-gray-600 text-sm">
                        {formatTime(record.loginTime)}
                      </td>
                      <td className="py-3 px-2 sm:px-4 text-gray-600 text-sm">
                        {record.logoutTime ? formatTime(record.logoutTime) : (
                          <span className="text-orange-600 font-medium text-xs">Active</span>
                        )}
                      </td>
                      <td className="py-3 px-2 sm:px-4 text-gray-600 text-sm">
                        {formatDuration(record.loginTime, record.logoutTime)}
                      </td>
                      <td className="py-3 px-2 sm:px-4">
                        {record.logoutTime ? (
                          <span className="px-2 py-1 bg-green-100 text-green-800 rounded-full text-xs font-medium">
                            Completed
                          </span>
                        ) : (
                          <span className="px-2 py-1 bg-orange-100 text-orange-800 rounded-full text-xs font-medium">
                            Active
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="text-center py-12">
              <Calendar className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-600 mb-2">No Records Found</h3>
              <p className="text-gray-500">No drivers logged in on this date</p>
            </div>
          )}
        </div>

        {/* Recent Activity */}
        {activeDrivers.length > 0 && (
          <div className="bg-white rounded-lg p-6 shadow">
            <h3 className="text-lg font-medium text-gray-800 mb-6">Currently Active Drivers</h3>
            <div className="space-y-3">
              {activeDrivers.map((record) => (
                <div key={record.id} className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 p-4 bg-green-50 border border-green-200 rounded-lg">
                  <div className="flex items-center space-x-3 min-w-0">
                    <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                    <div className="min-w-0 flex-1">
                      <div className="font-medium text-gray-800 truncate">{record.driverName}</div>
                      <div className="text-sm text-gray-600">
                        Logged in at {formatTime(record.loginTime)}
                      </div>
                    </div>
                  </div>
                  <div className="text-left sm:text-right flex-shrink-0">
                    <div className="text-sm font-medium text-green-800">
                      {formatDuration(record.loginTime)}
                    </div>
                    <div className="text-xs text-green-600">Active</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    );
  };

  const renderTelegram = () => (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
      <div className="bg-white rounded-lg p-4 shadow">
        <h3 className="text-lg font-medium text-gray-800 mb-4">Bot Settings</h3>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Bot Token
            </label>
            <div className="relative">
              <input
                type={showToken ? 'text' : 'password'}
                value={telegramSettings.token}
                onChange={(e) => updateTelegramSettings({
                  ...telegramSettings,
                  token: e.target.value
                })}
                placeholder="Enter your Telegram bot token"
                className="w-full px-3 py-2 pr-10 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
              />
              <button
                type="button"
                onClick={() => setShowToken(!showToken)}
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
              >
                {showToken ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Chat ID
            </label>
            <input
              type="text"
              value={telegramSettings.chatId}
              onChange={(e) => updateTelegramSettings({
                ...telegramSettings,
                chatId: e.target.value
              })}
              placeholder="Enter your Telegram chat ID"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
            />
          </div>

          <div className="space-y-4">
            <button
              onClick={handleTestConnection}
              disabled={telegram.isLoading || !telegramSettings.token}
              className={`w-full py-3 rounded-lg font-medium flex items-center justify-center space-x-2 transition-colors ${
                telegram.isLoading
                  ? 'bg-gray-400 text-white cursor-not-allowed'
                  : telegramSettings.token
                  ? 'bg-blue-500 text-white hover:bg-blue-600'
                  : 'bg-gray-300 text-gray-500 cursor-not-allowed'
              }`}
            >
              <Send className="w-4 h-4" />
              <span>{telegram.isLoading ? 'Testing...' : 'Test Connection'}</span>
            </button>

            {testResult && (
              <div className={`p-4 rounded-lg ${
                testResult.success ? 'bg-green-50 border border-green-200' : 'bg-red-50 border border-red-200'
              }`}>
                <div className={`font-medium ${testResult.success ? 'text-green-800' : 'text-red-800'}`}>
                  {testResult.success ? '✅ Connection Successful!' : '❌ Connection Failed'}
                </div>
                {testResult.success && testResult.botInfo && (
                  <div className="text-green-700 text-sm mt-2">
                    Bot: @{testResult.botInfo.username} ({testResult.botInfo.first_name})
                  </div>
                )}
                {!testResult.success && testResult.error && (
                  <div className="text-red-700 text-sm mt-2">
                    Error: {testResult.error}
                  </div>
                )}
              </div>
            )}
          </div>

          <div className="flex items-center space-x-2 pt-2">
            <div className={`w-3 h-3 rounded-full ${telegramSettings.token && telegramSettings.chatId ? 'bg-green-500' : 'bg-red-500'}`}></div>
            <span className={`text-sm font-medium ${telegramSettings.token && telegramSettings.chatId ? 'text-green-600' : 'text-red-600'}`}>
              {telegramSettings.token && telegramSettings.chatId ? 'Configuration Complete' : 'Configuration Required'}
            </span>
          </div>
        </div>
      </div>

      {/* Chat ID Finder */}
      {telegramSettings.token && (
        <div className="bg-white rounded-lg p-4 shadow">
          <ChatIdFinder botToken={telegramSettings.token} />
        </div>
      )}

      <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
        <h4 className="text-lg font-medium text-orange-800 mb-3">🔧 Setup Instructions</h4>
        <ol className="text-orange-700 space-y-2 list-decimal list-inside text-sm">
          <li>Create a bot by messaging <strong>@BotFather</strong> on Telegram</li>
          <li>Copy the bot token from BotFather</li>
          <li>Add your bot to the desired group/chat</li>
          <li><strong>Wichtig:</strong> Gib dem Bot Admin-Rechte in der Gruppe (oder zumindest "Nachrichten senden")</li>
          <li>Schreibe eine Nachricht in die Gruppe, dann besuche (ersetze [TOKEN]):<br/>
            <code className="text-xs bg-orange-100 px-2 py-1 rounded mt-1 block break-all">
              https://api.telegram.org/bot[TOKEN]/getUpdates
            </code>
          </li>
          <li>Finde deine Chat ID in der Antwort (meist eine negative Zahl für Gruppen)</li>
          <li>Verwende den "Test Connection" Button oben zur Überprüfung</li>
        </ol>
        
        <div className="mt-4 p-3 bg-orange-100 rounded-lg">
          <h5 className="font-medium text-orange-800 mb-2">🚨 Häufige Probleme:</h5>
          <ul className="text-orange-700 text-xs space-y-1 list-disc list-inside">
            <li><strong>"chat not found":</strong> Bot ist nicht in der Gruppe oder Chat ID ist falsch</li>
            <li><strong>"Forbidden":</strong> Bot hat keine Berechtigung, Nachrichten zu senden</li>
            <li><strong>"Unauthorized":</strong> Bot Token ist ungültig</li>
          </ul>
        </div>
        
        <div className="mt-4 p-3 bg-green-100 rounded-lg">
          <h5 className="font-medium text-green-800 mb-2">✅ Chat ID Format:</h5>
          <ul className="text-green-700 text-xs space-y-1 list-disc list-inside">
            <li><strong>Gruppen:</strong> -1001234567890 (beginnt mit -100)</li>
            <li><strong>Private Chats:</strong> 123456789 (positive Zahl)</li>
            <li><strong>Kanäle:</strong> @channelname oder -1001234567890</li>
          </ul>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Compact Navigation */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-6xl mx-auto px-4 py-3">
          <div className="flex items-center justify-between mb-4">
            <button
              onClick={onClose}
              className="flex items-center space-x-2 text-gray-600 hover:text-gray-800 transition-colors bg-gray-100 hover:bg-gray-200 px-3 py-2 rounded-lg text-sm"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back to App</span>
            </button>
            
            <div className="flex items-center space-x-2">
              <Settings className="w-5 h-5 text-blue-600" />
              <span className="font-bold text-gray-800">Admin Panel</span>
            </div>
            
            <div></div>
          </div>
          
          {/* Overview Tab and Save Button */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => setActiveSection('overview')}
                className={`text-lg font-semibold transition-colors hover:text-blue-600 ${
                  activeSection === 'overview' ? 'text-gray-800' : 'text-blue-500'
                }`}
              >
                Overview
              </button>
            </div>
            
            <button
              onClick={saveData}
              disabled={saveStatus === 'saving'}
              className={`px-4 py-2 rounded-lg text-sm font-medium flex items-center space-x-2 transition-colors ${
                saveStatus === 'saved' 
                  ? 'bg-green-500 text-white' 
                  : saveStatus === 'saving'
                  ? 'bg-gray-400 text-white cursor-not-allowed'
                  : 'bg-blue-500 text-white hover:bg-blue-600'
              }`}
            >
              <Save className="w-4 h-4" />
              <span>
                {saveStatus === 'saving' ? 'Saving...' : saveStatus === 'saved' ? 'Saved!' : 'Save All Changes'}
              </span>
            </button>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-6xl mx-auto px-4 py-6">
        {activeSection === 'overview' && renderOverview()}
        {activeSection === 'drivers' && renderDrivers()}
        {activeSection === 'cast' && renderCast()}
        {activeSection === 'messages' && renderMessages()}
        {activeSection === 'telegram' && renderTelegram()}
        {activeSection === 'missions' && renderMissions()}
        {activeSection === 'timetracking' && renderTimeTracking()}
      </div>
    </div>
  );
};