import React from 'react';
import { Car, ShoppingCart, UserPlus } from 'lucide-react';
import { useData } from '../contexts/DataContext';
import { Footer } from './Footer';

interface HomeScreenProps {
  onCastPickupClick: () => void;
  onSideMissionsClick: () => void;
  onAdminClick: () => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  onCastPickupClick,
  onSideMissionsClick,
  onAdminClick,
}) => {
  const { sideMissions } = useData();
  
  // Count available missions (new missions that haven't been taken yet)
  const availableMissionsCount = sideMissions.filter(mission => 
    mission.status === 'available'
  ).length;

  return (
    <div className="min-h-screen p-4 pt-2 pb-20" style={{ backgroundColor: '#7ed957' }}>
      <div className="max-w-md mx-auto">
        <div className="text-center mb-8">
          <div className="w-40 h-40 mx-auto mb-4 flex items-center justify-center">
            <img 
              src="/J.png" 
              alt="Cast PickUp Bot Logo" 
              className="w-full h-full object-contain"
            />
          </div>
          <h1 className="text-4xl font-black text-gray-800 mb-2 tracking-wide">DRIVERS BOT</h1>
          <p className="text-gray-600">Choose your mission</p>
        </div>

        {/* Mission Buttons */}
        <div className="grid grid-cols-2 gap-4">
          <button
            onClick={onCastPickupClick}
            className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-all duration-200 transform hover:scale-105"
          >
            <div className="flex flex-col items-center space-y-3">
              <div className="w-16 h-16 bg-blue-100 rounded-xl flex items-center justify-center">
                <div className="relative">
                  <Car className="w-8 h-8 text-blue-600" />
                  <UserPlus className="w-4 h-4 text-blue-600 absolute -top-1 -right-1 bg-white rounded-full p-0.5" />
                </div>
              </div>
              <div className="text-center">
                <h2 className="text-lg font-bold text-gray-800">Cast PickUp</h2>
                <p className="text-xs text-gray-600 leading-tight">Transport cast members</p>
              </div>
            </div>
          </button>

          <button
            onClick={onSideMissionsClick}
            className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-all duration-200 transform hover:scale-105 relative"
          >
            {/* Notification Badge */}
            {availableMissionsCount > 0 && (
              <div className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 rounded-full flex items-center justify-center z-10 shadow-lg">
                <span className="text-white text-xs font-bold">
                  {availableMissionsCount > 99 ? '99+' : availableMissionsCount}
                </span>
              </div>
            )}
            
            <div className="flex flex-col items-center space-y-3">
              <div className="w-16 h-16 bg-orange-100 rounded-xl flex items-center justify-center">
                <ShoppingCart className="w-8 h-8 text-orange-600" />
              </div>
              <div className="text-center">
                <h2 className="text-lg font-bold text-gray-800">Side Missions</h2>
                <p className="text-xs text-gray-600 leading-tight">Additional tasks</p>
              </div>
            </div>
          </button>
        </div>
      </div>
      <Footer onAdminClick={onAdminClick} />
    </div>
  );
};