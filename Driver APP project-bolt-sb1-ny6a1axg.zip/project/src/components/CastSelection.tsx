import React, { useState } from 'react';
import { CastMember } from '../types';
import { useData } from '../contexts/DataContext';
import { ChevronDown, ChevronUp, Check, ArrowLeft } from 'lucide-react';
import { Footer } from './Footer';

interface CastSelectionProps {
  selectedCastMembers: CastMember[];
  onCastMemberToggle: (castMember: CastMember) => void;
  onNext: () => void;
  onGoBack: () => void;
  onAdminClick: () => void;
}

export const CastSelection: React.FC<CastSelectionProps> = ({
  selectedCastMembers,
  onCastMemberToggle,
  onNext,
  onGoBack,
  onAdminClick,
}) => {
  const { castMembers } = useData();
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  const isSelected = (castMember: CastMember) =>
    selectedCastMembers.some(selected => selected.id === castMember.id);

  return (
    <div className="min-h-screen p-4 pt-2 pb-20" style={{ backgroundColor: '#7ed957' }}>
      <div className="max-w-md mx-auto">
        {/* Back Button */}
        <button
          onClick={onGoBack}
          className="mb-4 flex items-center space-x-2 text-gray-600 hover:text-gray-800 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          <span className="text-sm font-medium">Back to Driver Selection</span>
        </button>

        <div className="text-center mb-8">
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-800 mb-2">Select Cast Members</h1>
          <p className="text-sm sm:text-base text-gray-600">Choose who you're picking up</p>
        </div>

        {/* Dropdown */}
        <div className="relative mb-6">
          <button
            onClick={() => setIsDropdownOpen(!isDropdownOpen)}
            className="w-full bg-white rounded-xl p-4 sm:p-5 flex items-center justify-between shadow-md hover:shadow-lg transition-shadow"
          >
            <span className="text-base sm:text-lg font-medium text-gray-700">
              {selectedCastMembers.length === 0
                ? 'Select cast members...'
                : `${selectedCastMembers.length} selected`}
            </span>
            {isDropdownOpen ? (
              <ChevronUp className="w-5 h-5 sm:w-6 sm:h-6 text-gray-500" />
            ) : (
              <ChevronDown className="w-5 h-5 sm:w-6 sm:h-6 text-gray-500" />
            )}
          </button>

          {isDropdownOpen && (
            <div className="absolute top-full left-0 right-0 mt-2 bg-white rounded-xl shadow-xl border border-gray-100 overflow-y-auto z-10" style={{ maxHeight: '192px' }}>
              {castMembers.map((castMember) => (
                <button
                  key={castMember.id}
                  onClick={() => onCastMemberToggle(castMember)}
                  className={`w-full p-3 sm:p-4 text-left flex items-center justify-between hover:bg-gray-50 transition-colors ${
                    isSelected(castMember) ? 'bg-blue-50' : ''
                  }`}
                >
                  <span
                    className={`font-medium text-sm sm:text-base ${
                      isSelected(castMember) ? 'text-blue-600' : 'text-gray-700'
                    }`}
                  >
                    {castMember.name}
                  </span>
                  {isSelected(castMember) && (
                    <Check className="w-5 h-5 text-blue-600" />
                  )}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Selected Cast Members Display */}
        {selectedCastMembers.length > 0 && (
          <div className="mb-6">
            <h3 className="text-base sm:text-lg font-semibold text-gray-700 mb-3">Selected Cast Members:</h3>
            <div className="space-y-2">
              {selectedCastMembers.map((castMember) => (
                <div
                  key={castMember.id}
                  className="bg-blue-100 text-blue-800 px-3 sm:px-4 py-2 sm:py-3 rounded-lg flex items-center justify-between"
                >
                  <span className="font-medium text-sm sm:text-base">{castMember.name}</span>
                  <button
                    onClick={() => onCastMemberToggle(castMember)}
                    className="text-blue-600 hover:text-blue-800 text-lg sm:text-xl"
                  >
                    ×
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Next Button */}
        {selectedCastMembers.length > 0 && (
          <div className="space-y-3">
            <button
              onClick={() => {
                setIsDropdownOpen(false);
                onNext();
              }}
              className="w-full bg-primary-500 text-white py-3 sm:py-4 rounded-xl text-base sm:text-lg font-semibold hover:bg-primary-600 transition-colors shadow-lg"
            >
              Continue to ETA Selection
            </button>
          </div>
        )}
      </div>
      <Footer onAdminClick={onAdminClick} />
    </div>
  );
};