import React, { useRef, useEffect, useState, useCallback } from 'react';

interface TimePickerProps {
  hours: number;
  minutes: number;
  onTimeChange: (hours: number, minutes: number) => void;
}

export const TimePicker: React.FC<TimePickerProps> = ({
  hours,
  minutes,
  onTimeChange,
}) => {
  const hoursRef = useRef<HTMLDivElement>(null);
  const minutesRef = useRef<HTMLDivElement>(null);
  const [isScrolling, setIsScrolling] = useState({ hours: false, minutes: false });

  const hourOptions = Array.from({ length: 24 }, (_, i) => i);
  const minuteOptions = Array.from({ length: 60 }, (_, i) => i);

  const itemHeight = 60;

  const scrollToValue = useCallback((ref: React.RefObject<HTMLDivElement>, value: number) => {
    if (ref.current) {
      const targetScrollTop = value * itemHeight;
      ref.current.scrollTo({
        top: targetScrollTop,
        behavior: 'smooth'
      });
    }
  }, []);

  useEffect(() => {
    // Initial scroll to current values
    setTimeout(() => {
      scrollToValue(hoursRef, hours);
      scrollToValue(minutesRef, minutes);
    }, 100);
  }, [hours, minutes, scrollToValue]);

  const handleScroll = useCallback((
    ref: React.RefObject<HTMLDivElement>,
    options: number[],
    onChange: (value: number) => void,
    type: 'hours' | 'minutes'
  ) => {
    if (!ref.current) return;
    
    const scrollTop = ref.current.scrollTop;
    const index = Math.round(scrollTop / itemHeight);
    const clampedIndex = Math.max(0, Math.min(index, options.length - 1));
    const newValue = options[clampedIndex];
    
    onChange(newValue);
    
    // Set scrolling state
    setIsScrolling(prev => ({ ...prev, [type]: true }));
    
    // Clear scrolling state after a delay
    setTimeout(() => {
      setIsScrolling(prev => ({ ...prev, [type]: false }));
    }, 150);
  }, []);

  const createScrollHandler = useCallback((
    ref: React.RefObject<HTMLDivElement>,
    options: number[],
    onChange: (value: number) => void,
    type: 'hours' | 'minutes'
  ) => {
    let scrollTimeout: NodeJS.Timeout;
    
    return () => {
      clearTimeout(scrollTimeout);
      scrollTimeout = setTimeout(() => {
        handleScroll(ref, options, onChange, type);
      }, 50);
    };
  }, [handleScroll]);

  const hoursScrollHandler = createScrollHandler(
    hoursRef,
    hourOptions,
    (h) => onTimeChange(h, minutes),
    'hours'
  );

  const minutesScrollHandler = createScrollHandler(
    minutesRef,
    minuteOptions,
    (m) => onTimeChange(hours, m),
    'minutes'
  );

  const renderWheel = (
    ref: React.RefObject<HTMLDivElement>,
    options: number[],
    selectedValue: number,
    onScroll: () => void,
    type: 'hours' | 'minutes',
    formatter: (value: number) => string = (v) => v.toString().padStart(2, '0')
  ) => (
    <div className="relative">
      <div
        ref={ref}
        className="h-40 sm:h-48 overflow-y-auto scrollbar-hide snap-y snap-mandatory"
        style={{ 
          scrollbarWidth: 'none', 
          msOverflowStyle: 'none',
          scrollBehavior: 'smooth'
        }}
        onScroll={onScroll}
      >
        {/* Top padding */}
        <div style={{ height: '70px' }} className="sm:h-[90px]" />
        
        {options.map((option) => (
          <div
            key={option}
            className={`flex items-center justify-center text-lg sm:text-2xl font-bold transition-all duration-300 snap-center ${
              option === selectedValue && !isScrolling[type]
                ? 'text-primary-600 scale-110 transform'
                : 'text-gray-400 scale-100'
            }`}
            style={{ height: `${itemHeight}px` }}
          >
            {formatter(option)}
          </div>
        ))}
        
        {/* Bottom padding */}
        <div style={{ height: '70px' }} className="sm:h-[90px]" />
      </div>
      
      {/* Selection indicator */}
      <div 
        className="absolute top-1/2 left-0 right-0 border-t-2 border-b-2 border-primary-500 pointer-events-none transform -translate-y-1/2 bg-primary-50 bg-opacity-20 rounded-lg" 
        style={{ height: `${itemHeight}px` }} 
      />
      
      {/* Gradient overlays for better visual effect */}
      <div className="absolute top-0 left-0 right-0 h-16 sm:h-20 bg-gradient-to-b from-white to-transparent pointer-events-none" />
      <div className="absolute bottom-0 left-0 right-0 h-16 sm:h-20 bg-gradient-to-t from-white to-transparent pointer-events-none" />
    </div>
  );

  return (
    <div className="bg-white rounded-xl p-4 sm:p-6 shadow-lg">
      <h3 className="text-lg sm:text-xl font-bold text-center text-gray-800 mb-4 sm:mb-6">Set ETA Time</h3>
      
      <div className="flex items-center justify-center space-x-4 sm:space-x-8">
        <div className="text-center">
          <div className="text-xs sm:text-sm font-medium text-gray-600 mb-2">Hours</div>
          {renderWheel(
            hoursRef, 
            hourOptions, 
            hours, 
            hoursScrollHandler,
            'hours'
          )}
        </div>
        
        <div className="text-2xl sm:text-4xl font-bold text-primary-500 mt-6 sm:mt-8 animate-pulse">:</div>
        
        <div className="text-center">
          <div className="text-xs sm:text-sm font-medium text-gray-600 mb-2">Minutes</div>
          {renderWheel(
            minutesRef, 
            minuteOptions, 
            minutes, 
            minutesScrollHandler,
            'minutes'
          )}
        </div>
      </div>
      
      <div className="mt-4 sm:mt-6 text-center">
        <div className="text-base sm:text-lg font-semibold text-gray-700 bg-gray-50 rounded-lg py-2 sm:py-3 px-4 sm:px-6">
          Selected ETA: <span className="text-primary-600 text-lg sm:text-xl">{hours.toString().padStart(2, '0')}:{minutes.toString().padStart(2, '0')}</span>
        </div>
      </div>
    </div>
  );
};