import React, { useState } from 'react';
import { SideMission, Driver } from '../types';
import { useData } from '../contexts/DataContext';
import { useAuth } from '../contexts/AuthContext';
import { ArrowLeft, Clock, MapPin, AlertCircle, User, ChevronDown, ChevronUp, ShoppingCart } from 'lucide-react';
import { Footer } from './Footer';

interface SideMissionsOverviewProps {
  onGoBack: () => void;
  onAdminClick: () => void;
}

export const SideMissionsOverview: React.FC<SideMissionsOverviewProps> = ({
  onGoBack,
  onAdminClick,
}) => {
  const { sideMissions, drivers, updateSideMissions } = useData();
  const { currentDriver } = useAuth();
  const [selectedMission, setSelectedMission] = useState<SideMission | null>(null);
  const [selectedDriver, setSelectedDriver] = useState<string>('');
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  const availableMissions = sideMissions.filter(mission => mission.status === 'available');
  const myAssignedMissions = sideMissions.filter(mission => 
    mission.status === 'assigned' && mission.assignedDriver === currentDriver?.id
  );
  const myCompletedMissions = sideMissions.filter(mission => 
    mission.status === 'completed' && mission.assignedDriver === currentDriver?.id
  );

  const completeMission = (id: string) => {
    updateSideMissions(sideMissions.map(m => 
      m.id === id ? { ...m, status: 'completed' as const } : m
    ));
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-800 border-red-200';
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'low': return 'bg-green-100 text-green-800 border-green-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case 'high': return <AlertCircle className="w-4 h-4" />;
      case 'medium': return <Clock className="w-4 h-4" />;
      case 'low': return <Clock className="w-4 h-4" />;
      default: return <Clock className="w-4 h-4" />;
    }
  };

  const handleMissionClick = (mission: SideMission) => {
    if (mission.status === 'available') {
      setSelectedMission(mission);
      setSelectedDriver('');
      setIsDropdownOpen(false);
    }
  };

  const handleAssignMission = () => {
    if (selectedMission && selectedDriver) {
      const updatedMissions = sideMissions.map(mission =>
        mission.id === selectedMission.id
          ? { ...mission, status: 'assigned' as const, assignedDriver: currentDriver?.id }
          : mission
      );
      updateSideMissions(updatedMissions);
      setSelectedMission(null);
      setSelectedDriver('');
    }
  };

  const handleDriverSelect = (driverId: string) => {
    setSelectedDriver(driverId);
    setIsDropdownOpen(false);
  };

  const getDriverName = (driverId: string) => {
    const driver = drivers.find(d => d.id === driverId);
    return driver ? driver.name : 'Unknown Driver';
  };

  if (selectedMission) {
    return (
      <div className="min-h-screen p-4 pt-2 pb-20" style={{ backgroundColor: '#7ed957' }}>
        <div className="max-w-md mx-auto">
          {/* Back Button */}
          <button
            onClick={() => setSelectedMission(null)}
            className="mb-4 flex items-center space-x-2 text-gray-600 hover:text-gray-800 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span className="text-sm font-medium">Back to Missions</span>
          </button>

          <div className="bg-white rounded-xl p-6 shadow-lg mb-6">
            <div className="flex items-center justify-between mb-4">
              <h1 className="text-2xl font-bold text-gray-800">{selectedMission.title}</h1>
              <div className={`px-3 py-1 rounded-full text-sm font-medium border flex items-center space-x-1 ${getPriorityColor(selectedMission.priority)}`}>
                {getPriorityIcon(selectedMission.priority)}
                <span className="capitalize">{selectedMission.priority}</span>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-medium text-gray-600 mb-1">DESCRIPTION</h3>
                <p className="text-gray-800">{selectedMission.description}</p>
              </div>

              <div>
                <h3 className="text-sm font-medium text-gray-600 mb-1">LOCATION</h3>
                <div className="flex items-center space-x-2 text-gray-800">
                  <MapPin className="w-4 h-4" />
                  <span>{selectedMission.location}</span>
                </div>
              </div>

              <div>
                <h3 className="text-sm font-medium text-gray-600 mb-1">ESTIMATED DURATION</h3>
                <div className="flex items-center space-x-2 text-gray-800">
                  <Clock className="w-4 h-4" />
                  <span>{selectedMission.estimatedDuration}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Driver Selection */}
          <div className="bg-white rounded-xl p-6 shadow-lg mb-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Assign to Driver</h3>
            
            <div className="mb-4">
              <div className="w-full bg-blue-50 rounded-lg p-4 border border-blue-200">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                    <User className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <div className="font-medium text-blue-800">Assigning to:</div>
                    <div className="text-blue-700">{currentDriver?.name}</div>
                  </div>
                </div>
              </div>
            </div>

            <button
              onClick={() => {
                if (currentDriver) {
                  setSelectedDriver(currentDriver.id);
                  handleAssignMission();
                }
              }}
              className="w-full py-4 rounded-xl text-lg font-semibold transition-colors shadow-lg bg-primary-500 text-white hover:bg-primary-600"
            >
              Accept This Mission
            </button>
          </div>
        </div>
        <Footer onAdminClick={onAdminClick} />
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 pt-2 pb-20" style={{ backgroundColor: '#7ed957' }}>
      <div className="max-w-md mx-auto">
        {/* Back Button */}
        <button
          onClick={onGoBack}
          className="mb-4 flex items-center space-x-2 text-gray-600 hover:text-gray-800 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          <span className="text-sm font-medium">Back to Home</span>
        </button>

        <div className="text-center mb-8">
          {/* Large Side Missions Icon */}
          <div className="w-24 h-24 sm:w-32 sm:h-32 mx-auto mb-6 bg-orange-100 rounded-3xl flex items-center justify-center shadow-lg">
            <ShoppingCart className="w-12 h-12 sm:w-16 sm:h-16 text-orange-600" />
          </div>
          
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-800 mb-2">Side Missions</h1>
          <p className="text-sm sm:text-base text-gray-600">Available tasks and assignments</p>
          <p className="text-xs sm:text-sm text-gray-500 italic">... if you are willing to accept.</p>
        </div>

        {/* Available Missions */}
        {availableMissions.length > 0 && (
          <div className="mb-6">
            <h2 className="text-base sm:text-lg font-semibold text-gray-700 mb-4">Available Missions</h2>
            <div className="space-y-3">
              {availableMissions.map((mission) => (
                <button
                  key={mission.id}
                  onClick={() => handleMissionClick(mission)}
                  className="w-full bg-white rounded-xl p-4 sm:p-6 shadow-md hover:shadow-lg transition-all duration-200 text-left"
                >
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="text-base sm:text-lg font-semibold text-gray-800 flex-1 pr-2">{mission.title}</h3>
                    <div className={`px-2 py-1 rounded-full text-xs font-medium border flex items-center space-x-1 flex-shrink-0 ${getPriorityColor(mission.priority)}`}>
                      {getPriorityIcon(mission.priority)}
                      <span className="capitalize hidden sm:inline">{mission.priority}</span>
                    </div>
                  </div>
                  <p className="text-gray-600 text-xs sm:text-sm mb-2 line-clamp-2">{mission.description}</p>
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between text-xs sm:text-sm text-gray-500 space-y-1 sm:space-y-0">
                    <div className="flex items-center space-x-1">
                      <MapPin className="w-3 h-3" />
                      <span className="truncate">{mission.location}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Clock className="w-3 h-3" />
                      <span>{mission.estimatedDuration}</span>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Assigned Missions */}
        {myAssignedMissions.length > 0 && (
          <div className="mb-6">
            <h2 className="text-base sm:text-lg font-semibold text-gray-700 mb-4">My Current Tasks</h2>
            <div className="space-y-3">
              {myAssignedMissions.map((mission) => (
                <div
                  key={mission.id}
                  className="w-full bg-orange-50 border border-orange-200 rounded-xl p-4 sm:p-6 shadow-md"
                >
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="text-base sm:text-lg font-semibold text-orange-800 flex-1 pr-2">{mission.title}</h3>
                    <div className={`px-2 py-1 rounded-full text-xs font-medium border flex items-center space-x-1 flex-shrink-0 ${getPriorityColor(mission.priority)}`}>
                      {getPriorityIcon(mission.priority)}
                      <span className="capitalize hidden sm:inline">{mission.priority}</span>
                    </div>
                  </div>
                  <p className="text-orange-700 text-xs sm:text-sm mb-3 line-clamp-2">{mission.description}</p>
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between text-xs sm:text-sm text-orange-600 space-y-2 sm:space-y-0 mb-3">
                    <div className="flex items-center space-x-1">
                      <MapPin className="w-3 h-3" />
                      <span className="truncate">{mission.location}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Clock className="w-3 h-3" />
                      <span>{mission.estimatedDuration}</span>
                    </div>
                  </div>
                  
                  {/* Complete Button - Below the current task */}
                  <button
                    onClick={() => completeMission(mission.id)}
                    className="w-full bg-green-500 text-white py-2 px-4 rounded-lg hover:bg-green-600 transition-colors font-medium text-sm"
                  >
                    Mark as Completed
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Completed Missions */}
        {myCompletedMissions.length > 0 && (
          <div className="mb-6">
            <h2 className="text-base sm:text-lg font-semibold text-gray-700 mb-4">My Completed Tasks</h2>
            <div className="space-y-3">
              {myCompletedMissions.slice(-3).map((mission) => (
                <div
                  key={mission.id}
                  className="w-full bg-green-50 border border-green-200 rounded-xl p-4 sm:p-6 shadow-md opacity-75"
                >
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="text-base sm:text-lg font-semibold text-green-700 flex-1 pr-2">{mission.title}</h3>
                    <div className="px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                      ✓ Completed
                    </div>
                  </div>
                  <p className="text-green-600 text-xs sm:text-sm mb-2 line-clamp-2">{mission.description}</p>
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between text-xs sm:text-sm text-green-500 space-y-1 sm:space-y-0">
                    <div className="flex items-center space-x-1">
                      <MapPin className="w-3 h-3" />
                      <span className="truncate">{mission.location}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Clock className="w-3 h-3" />
                      <span>{mission.estimatedDuration}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
        {availableMissions.length === 0 && myAssignedMissions.length === 0 && (
          <div className="text-center py-12">
            <MapPin className="w-12 h-12 sm:w-16 sm:h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg sm:text-xl font-semibold text-gray-600 mb-2">No Missions Available</h3>
            <p className="text-sm sm:text-base text-gray-500">Check back later for new assignments</p>
          </div>
        )}
      </div>
      <Footer onAdminClick={onAdminClick} />
    </div>
  );
};
