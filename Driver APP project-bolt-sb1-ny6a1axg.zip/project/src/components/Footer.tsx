import React from 'react';
import { Settings } from 'lucide-react';

interface FooterProps {
  onAdminClick: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onAdminClick }) => {
  return (
    <div className="fixed bottom-0 left-0 right-0 px-6 py-3 flex items-center justify-between z-40 bg-white bg-opacity-90 backdrop-blur-sm border-t border-gray-200">
      <div className="text-sm text-gray-500">
        powered by <a 
          href="https://www.diejuten.de" 
          target="_blank" 
          rel="noopener noreferrer"
          className="font-semibold text-gray-700 hover:text-gray-900 transition-colors underline decoration-transparent hover:decoration-gray-700"
        >
          DIE JUTEN
        </a>
      </div>
      
      <button
        onClick={onAdminClick}
        className="p-2 text-gray-400 hover:text-gray-600 transition-colors hover:bg-gray-100 rounded-full"
        title="Admin Settings"
      >
        <Settings className="w-5 h-5" />
      </button>
    </div>
  );
};