import React, { useEffect } from 'react';
import { TimePicker } from './TimePicker';
import { ArrowLeft } from 'lucide-react';
import { Footer } from './Footer';

interface ETASelectionProps {
  hours: number;
  minutes: number;
  onTimeChange: (hours: number, minutes: number) => void;
  onConfirm: () => void;
  onGoBack: () => void;
  onAdminClick: () => void;
}

export const ETASelection: React.FC<ETASelectionProps> = ({
  hours,
  minutes,
  onTimeChange,
  onConfirm,
  onGoBack,
  onAdminClick,
}) => {
  // Set to current time when component mounts
  useEffect(() => {
    // Get current time in Central European Time
    const now = new Date();
    const cetTime = new Date(now.toLocaleString("en-US", {timeZone: "Europe/Berlin"}));
    const currentHours = cetTime.getHours();
    const currentMinutes = cetTime.getMinutes();
    
    // Only update if the current time is different from props
    if (hours !== currentHours || minutes !== currentMinutes) {
      onTimeChange(currentHours, currentMinutes);
    }
  }, []); // Empty dependency array means this runs once on mount

  return (
    <div className="min-h-screen p-4 pt-2 pb-20" style={{ backgroundColor: '#7ed957' }}>
      <div className="max-w-md mx-auto">
        {/* Back Button */}
        <button
          onClick={onGoBack}
          className="mb-4 flex items-center space-x-2 text-gray-600 hover:text-gray-800 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          <span className="text-sm font-medium">Back to Cast Selection</span>
        </button>

        <div className="text-center mb-8">
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-800 mb-2">Set ETA</h1>
          <p className="text-sm sm:text-base text-gray-600">When will you arrive at the destination?</p>
        </div>

        <TimePicker
          hours={hours}
          minutes={minutes}
          onTimeChange={onTimeChange}
        />

        <div className="mt-8 space-y-3">
          <button
            onClick={onConfirm}
            className="w-full bg-primary-500 text-white py-3 sm:py-4 rounded-xl text-base sm:text-lg font-semibold hover:bg-primary-600 transition-colors shadow-lg"
          >
            Confirm ETA
          </button>
        </div>
      </div>
      <Footer onAdminClick={onAdminClick} />
    </div>
  );
};