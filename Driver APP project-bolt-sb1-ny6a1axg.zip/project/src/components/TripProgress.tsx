import React from 'react';
import { Driver, CastMember } from '../types';
import { Clock, CheckCircle, ArrowLeft } from 'lucide-react';
import { Footer } from './Footer';

interface TripProgressProps {
  selectedDriver: Driver;
  selectedCastMembers: CastMember[];
  eta: { hours: number; minutes: number };
  onFiveMinWarning: () => void;
  onDropOff: () => void;
  onGoBack: () => void;
  onAdminClick: () => void;
}

export const TripProgress: React.FC<TripProgressProps> = ({
  selectedDriver,
  selectedCastMembers,
  eta,
  onFiveMinWarning,
  onDropOff,
  onGoBack,
  onAdminClick,
}) => {
  return (
    <div className="min-h-screen p-4 pt-2 pb-20" style={{ backgroundColor: '#7ed957' }}>
      <div className="max-w-md mx-auto">
        {/* Back Button */}
        <button
          onClick={onGoBack}
          className="mb-4 flex items-center space-x-2 text-gray-600 hover:text-gray-800 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          <span className="text-sm font-medium">Back to Home</span>
        </button>

        {/* Main Content Card */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-2xl">
          {/* Car Icon */}
          <div className="text-center mb-8">
            <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-full flex items-center justify-center mx-auto mb-6" style={{ backgroundColor: '#5ba142' }}>
              <div className="w-16 h-16 sm:w-20 sm:h-20 bg-white rounded-full flex items-center justify-center">
                <img 
                  src="/v300.png" 
                  alt="Car Icon" 
                  className="w-12 h-12 sm:w-16 sm:h-16 object-contain"
                />
              </div>
            </div>
          </div>

          {/* Trip Status */}
          <div className="text-center mb-8">
            <h1 className="text-2xl sm:text-3xl font-bold text-gray-800 mb-2">TRIP IN PROGRESS</h1>
          </div>

          {/* Driver Info */}
          <div className="text-center mb-6">
            <div className="text-xs sm:text-sm text-gray-500 mb-1">DRIVER</div>
            <div className="text-xl sm:text-2xl font-bold text-gray-800">{selectedDriver.name}</div>
          </div>

          {/* Cast Members */}
          <div className="text-center mb-6">
            <div className="text-xs sm:text-sm text-gray-500 mb-1">CAST MEMBERS</div>
            <div className="text-base sm:text-lg font-bold text-gray-800 max-w-xs mx-auto space-y-1">
              {selectedCastMembers.map((member, index) => (
                <div key={member.id} className="leading-tight">
                  {member.name}
                </div>
              ))}
            </div>
          </div>

          {/* ETA */}
          <div className="text-center mb-12">
            <div className="text-xs sm:text-sm text-gray-500 mb-1">ETA</div>
            <div className="text-3xl sm:text-4xl font-bold text-gray-800">
              {eta.hours.toString().padStart(2, '0')}:{eta.minutes.toString().padStart(2, '0')}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="space-y-4">
            <button
              onClick={onFiveMinWarning}
              className="w-full bg-warning-500 text-white py-3 sm:py-4 rounded-2xl text-base sm:text-lg font-semibold hover:bg-warning-600 transition-colors shadow-lg flex items-center justify-center space-x-3"
            >
              <Clock className="w-5 h-5 sm:w-6 sm:h-6" />
              <span>5 Minute Warning</span>
            </button>

            <button
              onClick={onDropOff}
              className="w-full bg-primary-500 text-white py-3 sm:py-4 rounded-2xl text-base sm:text-lg font-semibold hover:bg-primary-600 transition-colors shadow-lg flex items-center justify-center space-x-3"
            >
              <CheckCircle className="w-5 h-5 sm:w-6 sm:h-6" />
              <span>Drop Off</span>
            </button>
          </div>
        </div>
      </div>
      <Footer onAdminClick={onAdminClick} />
    </div>
  );
};