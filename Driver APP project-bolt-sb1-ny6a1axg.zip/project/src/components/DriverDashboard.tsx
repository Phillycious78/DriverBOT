import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Car, ShoppingCart, UserPlus, LogOut, Clock } from 'lucide-react';
import { useData } from '../contexts/DataContext';
import { Footer } from './Footer';

interface DriverDashboardProps {
  onCastPickupClick: () => void;
  onSideMissionsClick: () => void;
  onAdminClick: () => void;
}

export const DriverDashboard: React.FC<DriverDashboardProps> = ({
  onCastPickupClick,
  onSideMissionsClick,
  onAdminClick,
}) => {
  const { currentDriver, logout, loginTime, loginRecords } = useAuth();
  const { sideMissions } = useData();
  
  // Count available missions and missions assigned to current driver
  const availableMissionsCount = sideMissions.filter(mission => 
    mission.status === 'available'
  ).length;
  
  const myAssignedMissions = sideMissions.filter(mission => 
    mission.status === 'assigned' && mission.assignedDriver === currentDriver?.id
  ).length;

  // Get today's work duration
  const getTodayWorkDuration = () => {
    if (!currentDriver || !loginTime) return '';
    
    const today = new Date().toISOString().split('T')[0];
    const todayRecords = loginRecords.filter(record => 
      record.date === today && record.driverId === currentDriver.id
    );
    
    if (todayRecords.length === 0) return '';
    
    // Get the most recent login record for today
    const currentRecord = todayRecords.find(record => !record.logoutTime);
    if (!currentRecord) return '';
    
    const now = new Date();
    const durationMs = now.getTime() - currentRecord.loginTime.getTime();
    const hours = Math.floor(durationMs / (1000 * 60 * 60));
    const minutes = Math.floor((durationMs % (1000 * 60 * 60)) / (1000 * 60));
    
    return `${hours}h ${minutes}m`;
  };

  const formatLoginTime = (time: Date | null) => {
    if (!time) return '';
    return time.toLocaleTimeString('en-US', { 
      hour: '2-digit', 
      minute: '2-digit',
      hour12: true 
    });
  };

  const handleLogout = () => {
    const workDuration = getTodayWorkDuration();
    const confirmMessage = workDuration 
      ? `You've worked ${workDuration} today. Are you sure you want to sign out?`
      : 'Are you sure you want to sign out?';
      
    if (confirm(confirmMessage)) {
      logout();
    }
  };

  return (
    <div className="min-h-screen p-4 pt-2 pb-20" style={{ backgroundColor: '#7ed957' }}>
      <div className="max-w-md mx-auto">
        {/* Header with Driver Info */}
        <div className="bg-white rounded-xl p-4 sm:p-6 shadow-lg mb-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 sm:w-12 sm:h-12 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                <UserPlus className="w-5 h-5 sm:w-6 sm:h-6 text-blue-600" />
              </div>
              <div className="min-w-0 flex-1">
                <h2 className="text-base sm:text-lg font-bold text-gray-800 truncate">Welcome, {currentDriver?.name}</h2>
                <div className="space-y-1">
                  <div className="flex items-center space-x-1 text-xs sm:text-sm text-gray-500">
                    <Clock className="w-3 h-3" />
                    <span className="truncate">Signed in at {formatLoginTime(loginTime)}</span>
                  </div>
                  {getTodayWorkDuration() && (
                    <div className="text-xs sm:text-sm text-green-600 font-medium">
                      Work time: {getTodayWorkDuration()}
                    </div>
                  )}
                </div>
              </div>
            </div>
            <button
              onClick={handleLogout}
              className="p-2 text-gray-400 hover:text-red-600 transition-colors hover:bg-red-50 rounded-full"
              title="Sign Out"
            >
              <LogOut className="w-4 h-4 sm:w-5 sm:h-5" />
            </button>
          </div>
        </div>

        <div className="text-center mb-8">
          <div className="w-24 h-24 sm:w-32 sm:h-32 mx-auto mb-4 flex items-center justify-center">
            <img 
              src="/J.png" 
              alt="Drivers Bot Logo" 
              className="w-full h-full object-contain"
            />
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-gray-800 mb-2 tracking-wide">DRIVERS BOT</h1>
          <p className="text-sm sm:text-base text-gray-600">Choose your mission</p>
        </div>

        {/* Mission Buttons */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <button
            onClick={onCastPickupClick}
            className="bg-white rounded-xl p-4 sm:p-6 shadow-lg hover:shadow-xl transition-all duration-200 transform hover:scale-105"
          >
            <div className="flex flex-col sm:flex-col items-center space-y-3">
              <div className="w-12 h-12 sm:w-16 sm:h-16 bg-blue-100 rounded-xl flex items-center justify-center">
                <div className="relative">
                  <Car className="w-6 h-6 sm:w-8 sm:h-8 text-blue-600" />
                  <UserPlus className="w-3 h-3 sm:w-4 sm:h-4 text-blue-600 absolute -top-1 -right-1 bg-white rounded-full p-0.5" />
                </div>
              </div>
              <div className="text-center">
                <h2 className="text-base sm:text-lg font-bold text-gray-800">Cast PickUp</h2>
                <p className="text-xs sm:text-sm text-gray-600 leading-tight">Transport cast members</p>
              </div>
            </div>
          </button>

          <button
            onClick={onSideMissionsClick}
            className="bg-white rounded-xl p-4 sm:p-6 shadow-lg hover:shadow-xl transition-all duration-200 transform hover:scale-105 relative"
          >
            {/* Notification Badges */}
            <div className="absolute -top-2 -right-2 flex flex-col sm:flex-row space-y-1 sm:space-y-0 sm:space-x-1">
              {availableMissionsCount > 0 && (
                <div className="w-5 h-5 sm:w-6 sm:h-6 bg-blue-500 rounded-full flex items-center justify-center shadow-lg">
                  <span className="text-white text-xs sm:text-xs font-bold">
                    {availableMissionsCount > 99 ? '99+' : availableMissionsCount}
                  </span>
                </div>
              )}
              {myAssignedMissions > 0 && (
                <div className="w-5 h-5 sm:w-6 sm:h-6 bg-orange-500 rounded-full flex items-center justify-center shadow-lg">
                  <span className="text-white text-xs sm:text-xs font-bold">
                    {myAssignedMissions > 99 ? '99+' : myAssignedMissions}
                  </span>
                </div>
              )}
            </div>
            
            <div className="flex flex-col sm:flex-col items-center space-y-3">
              <div className="w-12 h-12 sm:w-16 sm:h-16 bg-orange-100 rounded-xl flex items-center justify-center">
                <ShoppingCart className="w-6 h-6 sm:w-8 sm:h-8 text-orange-600" />
              </div>
              <div className="text-center">
                <h2 className="text-base sm:text-lg font-bold text-gray-800">Side Missions</h2>
                <p className="text-xs sm:text-sm text-gray-600 leading-tight">
                  {myAssignedMissions > 0 ? `${myAssignedMissions} assigned to you` : 'Additional tasks'}
                </p>
              </div>
            </div>
          </button>
        </div>
      </div>
      <Footer onAdminClick={onAdminClick} />
    </div>
  );
};