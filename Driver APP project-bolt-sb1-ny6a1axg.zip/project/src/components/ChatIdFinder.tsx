import React, { useState } from 'react';
import { Search, Copy, CheckCircle } from 'lucide-react';

interface ChatIdFinderProps {
  botToken: string;
}

interface TelegramUpdate {
  update_id: number;
  message?: {
    message_id: number;
    from: {
      id: number;
      first_name: string;
      username?: string;
    };
    chat: {
      id: number;
      title?: string;
      type: string;
    };
    date: number;
    text?: string;
  };
}

interface TelegramUpdatesResponse {
  ok: boolean;
  result: TelegramUpdate[];
  description?: string;
}

export const ChatIdFinder: React.FC<ChatIdFinderProps> = ({ botToken }) => {
  const [updates, setUpdates] = useState<TelegramUpdate[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const fetchUpdates = async () => {
    if (!botToken) {
      setError('Bot Token ist erforderlich');
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      const url = `https://api.telegram.org/bot${botToken}/getUpdates`;
      console.log('Fetching updates from:', url);

      const response = await fetch(url);
      const data: TelegramUpdatesResponse = await response.json();

      console.log('Updates response:', data);

      if (!response.ok || !data.ok) {
        setError(data.description || `HTTP ${response.status}`);
        return;
      }

      setUpdates(data.result);
      
      if (data.result.length === 0) {
        setError('Keine Nachrichten gefunden. Schreibe eine Nachricht in die Gruppe und versuche es erneut.');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Netzwerkfehler');
    } finally {
      setIsLoading(false);
    }
  };

  const copyToClipboard = async (chatId: string) => {
    try {
      await navigator.clipboard.writeText(chatId);
      setCopiedId(chatId);
      setTimeout(() => setCopiedId(null), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  const formatChatType = (type: string) => {
    switch (type) {
      case 'group': return '👥 Gruppe';
      case 'supergroup': return '👥 Supergruppe';
      case 'private': return '👤 Privat';
      case 'channel': return '📢 Kanal';
      default: return type;
    }
  };

  const formatDate = (timestamp: number) => {
    return new Date(timestamp * 1000).toLocaleString('de-DE');
  };

  return (
    <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
      <h4 className="text-lg font-medium text-blue-800 mb-3">🔍 Chat ID Finder</h4>
      
      <div className="space-y-4">
        <div className="bg-blue-100 rounded-lg p-3">
          <h5 className="font-medium text-blue-800 mb-2">📋 Anleitung:</h5>
          <ol className="text-blue-700 text-sm space-y-1 list-decimal list-inside">
            <li>Stelle sicher, dass der Bot zur gewünschten Gruppe hinzugefügt wurde</li>
            <li>Schreibe eine Nachricht in die Gruppe (z.B. "Test")</li>
            <li>Klicke auf "Chat IDs suchen"</li>
            <li>Wähle die richtige Chat ID aus der Liste</li>
          </ol>
        </div>

        <button
          onClick={fetchUpdates}
          disabled={isLoading || !botToken}
          className={`w-full py-3 rounded-lg font-medium flex items-center justify-center space-x-2 transition-colors ${
            isLoading
              ? 'bg-gray-400 text-white cursor-not-allowed'
              : botToken
              ? 'bg-blue-500 text-white hover:bg-blue-600'
              : 'bg-gray-300 text-gray-500 cursor-not-allowed'
          }`}
        >
          <Search className="w-4 h-4" />
          <span>{isLoading ? 'Suche...' : 'Chat IDs suchen'}</span>
        </button>

        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-3">
            <div className="font-medium text-red-800">❌ Fehler</div>
            <div className="text-red-700 text-sm mt-1">{error}</div>
          </div>
        )}

        {updates.length > 0 && (
          <div className="space-y-3">
            <h5 className="font-medium text-blue-800">Gefundene Chats:</h5>
            
            {/* Group unique chats */}
            {Array.from(new Map(updates.map(update => [
              update.message?.chat.id.toString(),
              update.message?.chat
            ])).values()).map((chat) => {
              if (!chat) return null;
              
              const chatId = chat.id.toString();
              const isGroup = chat.type === 'group' || chat.type === 'supergroup';
              
              return (
                <div
                  key={chatId}
                  className={`bg-white rounded-lg p-4 border-2 transition-colors ${
                    isGroup ? 'border-green-200 bg-green-50' : 'border-gray-200'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <span className="text-lg">{formatChatType(chat.type)}</span>
                      <span className="font-medium text-gray-800">
                        {chat.title || 'Unbenannt'}
                      </span>
                      {isGroup && (
                        <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full">
                          Empfohlen für Gruppen
                        </span>
                      )}
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="font-mono text-sm bg-gray-100 px-3 py-2 rounded border">
                      {chatId}
                    </div>
                    
                    <button
                      onClick={() => copyToClipboard(chatId)}
                      className="flex items-center space-x-2 bg-blue-500 text-white px-3 py-2 rounded hover:bg-blue-600 transition-colors text-sm"
                    >
                      {copiedId === chatId ? (
                        <>
                          <CheckCircle className="w-4 h-4" />
                          <span>Kopiert!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-4 h-4" />
                          <span>Kopieren</span>
                        </>
                      )}
                    </button>
                  </div>
                  
                  <div className="text-xs text-gray-500 mt-2">
                    Chat-Typ: {chat.type} | ID: {chatId}
                  </div>
                </div>
              );
            })}
            
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
              <div className="font-medium text-yellow-800">💡 Tipp:</div>
              <div className="text-yellow-700 text-sm mt-1">
                Für Gruppen solltest du die Chat ID verwenden, die mit einer negativen Zahl beginnt (z.B. -1001234567890).
                Private Chats haben positive Zahlen.
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};