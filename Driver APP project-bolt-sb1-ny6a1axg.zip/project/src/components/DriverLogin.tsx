import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useData } from '../contexts/DataContext';
import { User, Lock, LogIn, ChevronDown, ChevronUp, Check } from 'lucide-react';
import { Footer } from './Footer';

interface DriverLoginProps {
  onAdminClick: () => void;
}

export const DriverLogin: React.FC<DriverLoginProps> = ({ onAdminClick }) => {
  const { login } = useAuth();
  const { drivers } = useData();
  const [username, setUsername] = useState('');
  const [pin, setPin] = useState('');
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleUsernameSelect = (driverName: string) => {
    setUsername(driverName);
    setIsDropdownOpen(false);
    setError('');
    setPin(''); // Clear PIN when changing driver
  };

  const handlePinInput = (digit: string) => {
    if (pin.length < 4) {
      setPin(prev => prev + digit);
      setError('');
    }
  };

  const handlePinClear = () => {
    setPin('');
    setError('');
  };

  const handleSubmit = async () => {
    if (!username.trim()) {
      setError('Please select your name first');
      return;
    }

    if (pin.length !== 4) {
      setError('Please enter a 4-digit PIN');
      return;
    }

    setIsLoading(true);
    setError('');

    try {
      // Simple PIN check - all drivers use PIN 2025
      if (pin === '2025') {
        const result = await login(username.trim(), '2025');
        
        if (!result.success) {
          setError('Login failed. Please try again.');
          setPin('');
        }
      } else {
        setError('Incorrect PIN. Try again.');
        setPin('');
      }
    } catch (err) {
      setError('An unexpected error occurred');
      setPin('');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen p-4 pt-2 pb-20" style={{ backgroundColor: '#7ed957' }}>
      <div className="max-w-md mx-auto">
        <div className="text-center mb-8">
          <div className="w-40 h-40 mx-auto mb-4 flex items-center justify-center">
            <img 
              src="/J.png" 
              alt="Drivers Bot Logo" 
              className="w-full h-full object-contain"
            />
          </div>
          <h1 className="text-4xl font-black text-gray-800 mb-2 tracking-wide">DRIVERS BOT</h1>
          <p className="text-gray-600">Sign in to access your dashboard</p>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg">
          <div className="text-center mb-6">
            <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <User className="w-8 h-8 text-blue-600" />
            </div>
            <h2 className="text-xl font-bold text-gray-800">Driver Login</h2>
          </div>

          <div className="space-y-6">
            {/* Username Selection */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Select Your Name
              </label>
              <div className="relative">
                <button
                  type="button"
                  onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                  disabled={isLoading}
                  className={`w-full px-4 py-3 pl-10 pr-10 border rounded-lg text-left focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm sm:text-base ${
                    error && !username ? 'border-red-500' : 'border-gray-300'
                  } ${isLoading ? 'bg-gray-100 cursor-not-allowed' : 'bg-white hover:bg-gray-50'}`}
                >
                  <span className={username ? 'text-gray-900' : 'text-gray-500'}>
                    {username || 'Select your name...'}
                  </span>
                </button>
                <User className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                {isDropdownOpen ? (
                  <ChevronUp className="absolute right-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                ) : (
                  <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                )}

                {isDropdownOpen && (
                  <div className="absolute top-full left-0 right-0 mt-2 bg-white rounded-lg shadow-xl border border-gray-100 z-10">
                    <div className="max-h-48 sm:max-h-36 overflow-y-auto">
                      {drivers.filter(driver => driver.isActive !== false).map((driver, index) => (
                        <button
                          key={driver.id}
                          type="button"
                          onClick={() => handleUsernameSelect(driver.name)}
                          className={`w-full p-3 sm:p-4 text-left hover:bg-gray-50 transition-colors flex items-center justify-between text-sm sm:text-base ${
                            index < drivers.length - 1 ? 'border-b border-gray-50' : ''
                          } ${username === driver.name ? 'bg-blue-50' : ''}`}
                        >
                          <span className={`font-medium ${username === driver.name ? 'text-blue-600' : 'text-gray-700'}`}>
                            {driver.name}
                          </span>
                          {username === driver.name && (
                            <Check className="w-4 h-4 text-blue-600" />
                          )}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* PIN Input */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Enter 4-Digit PIN
              </label>
              
              {/* PIN Keypad */}
              <div className="grid grid-cols-3 gap-2 sm:gap-3 max-w-xs mx-auto mb-4">
                {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((digit) => (
                  <button
                    key={digit}
                    type="button"
                    onClick={() => handlePinInput(digit.toString())}
                    disabled={isLoading || pin.length >= 4}
                    className="w-14 h-14 sm:w-16 sm:h-16 bg-gray-100 hover:bg-gray-200 rounded-lg text-lg sm:text-xl font-bold text-gray-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {digit}
                  </button>
                ))}
                
                {/* Bottom row: Clear, 0, Submit */}
                <button
                  type="button"
                  onClick={handlePinClear}
                  disabled={isLoading}
                  className="w-14 h-14 sm:w-16 sm:h-16 bg-red-100 hover:bg-red-200 rounded-lg text-xs sm:text-sm font-bold text-red-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Clear
                </button>
                
                <button
                  type="button"
                  onClick={() => handlePinInput('0')}
                  disabled={isLoading || pin.length >= 4}
                  className="w-14 h-14 sm:w-16 sm:h-16 bg-gray-100 hover:bg-gray-200 rounded-lg text-lg sm:text-xl font-bold text-gray-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  0
                </button>
                
                <button
                  type="button"
                  onClick={handleSubmit}
                  disabled={isLoading || !username || pin.length !== 4}
                  className="w-14 h-14 sm:w-16 sm:h-16 bg-blue-500 hover:bg-blue-600 rounded-lg text-white font-bold transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
                >
                  <LogIn className="w-4 h-4 sm:w-5 sm:h-5" />
                </button>
              </div>

              {/* PIN Display - Now below the keypad */}
              <div className="flex justify-center">
                <div className="flex space-x-3">
                  {[0, 1, 2, 3].map((index) => (
                    <div
                      key={index}
                      className={`w-8 h-8 sm:w-10 sm:h-10 border-2 rounded-lg flex items-center justify-center text-base sm:text-lg font-bold ${
                        pin.length > index 
                          ? 'border-blue-500 bg-blue-50 text-blue-600' 
                          : 'border-gray-300 bg-gray-50 text-gray-400'
                      }`}
                    >
                      {pin.length > index ? '●' : ''}
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-3">
                <p className="text-red-600 text-sm text-center">{error}</p>
              </div>
            )}

            {/* Instructions */}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
              <div className="text-center">
                <Lock className="w-5 h-5 sm:w-6 sm:h-6 text-blue-600 mx-auto mb-2" />
                <p className="text-blue-800 text-sm sm:text-base font-medium">PIN: 2025</p>
                <p className="text-blue-600 text-xs">Use the keypad above to enter your PIN</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Footer onAdminClick={onAdminClick} />
    </div>
  );
};