export interface Driver {
  id: string;
  name: string;
  username: string;
  password: string; // In production, this would be hashed
  isActive: boolean;
}

export interface AuthState {
  isAuthenticated: boolean;
  currentDriver: Driver | null;
  loginTime: Date | null;
}

export interface CastMember {
  id: string;
  name: string;
}

export interface AppState {
  currentStep: 'dashboard' | 'driver-selection' | 'cast-selection' | 'eta-selection' | 'action-selection' | 'trip-progress' | 'delay-report' | 'side-missions';
  selectedDriver: Driver | null;
  selectedCastMembers: CastMember[];
  eta: {
    hours: number;
    minutes: number;
  };
  tripStartTime: Date | null;
}

export interface TimePickerProps {
  hours: number;
  minutes: number;
  onTimeChange: (hours: number, minutes: number) => void;
}

export interface TelegramSettings {
  token: string;
  chatId: string;
}

export interface MessageTemplates {
  tripStarted: string;
  delayReported: string;
  fiveMinuteWarning: string;
  dropOffCompleted: string;
}

export interface LoginRecord {
  id: string;
  driverId: string;
  driverName: string;
  loginTime: Date;
  logoutTime?: Date;
  date: string; // YYYY-MM-DD format for easy grouping
}

export interface SideMission {
  id: string;
  title: string;
  description: string;
  location: string;
  priority: 'low' | 'medium' | 'high';
  estimatedDuration: string;
  assignedDriver?: string;
  createdAt: Date;
  status: 'available' | 'assigned' | 'completed';
}