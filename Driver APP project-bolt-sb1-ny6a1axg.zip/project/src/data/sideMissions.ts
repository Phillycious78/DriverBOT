import { SideMission } from '../types';

export const defaultSideMissions: SideMission[] = [
  {
    id: '1',
    title: 'Equipment Transport',
    description: 'Transport camera equipment from Studio A to Location B',
    location: 'Studio A → Location B',
    priority: 'high',
    estimatedDuration: '45 minutes',
    status: 'available',
    createdAt: new Date()
  },
  {
    id: '2',
    title: 'Catering Pickup',
    description: 'Pick up lunch orders from restaurant and deliver to set',
    location: 'Restaurant → Film Set',
    priority: 'medium',
    estimatedDuration: '30 minutes',
    status: 'available',
    createdAt: new Date()
  }
];