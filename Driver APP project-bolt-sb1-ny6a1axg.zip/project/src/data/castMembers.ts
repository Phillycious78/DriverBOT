import { CastMember } from '../types';

export const castMembers: CastMember[] = [
  { id: '1', name: 'Emma Stone' },
  { id: '2', name: 'Ryan Gosling' },
  { id: '3', name: 'Margot Robbie' },
  { id: '4', name: 'Leonardo DiCaprio' },
  { id: '5', name: 'Jennifer Lawrence' },
  { id: '6', name: 'Brad Pitt' },
  { id: '7', name: 'Scarlett Johansson' },
  { id: '8', name: 'Tom Hanks' },
  { id: '9', name: 'Meryl Streep' },
  { id: '10', name: 'Robert Downey Jr.' },
];