import { MessageTemplates } from '../types';

export const defaultMessageTemplates: MessageTemplates = {
  tripStarted: `🚗 TRIP STARTED

Driver: {driver}
Cast Members: {castMembers}
ETA: {eta}
Status: Trip started
Time: {time}`,

  delayReported: `⚠️ DELAY REPORTED

Driver: {driver}
Delayed Cast Members: {delayedCastMembers}
Time: {time}`,

  fiveMinuteWarning: `⏰ 5 MINUTE WARNING

Driver: {driver}
Cast Members: {castMembers}
Message: 5 minutes until arrival
Time: {time}`,

  dropOffCompleted: `✅ DROP-OFF COMPLETED

Driver: {driver}
Cast Members: {castMembers}
Message: Drop-off completed
Time: {time}`
};