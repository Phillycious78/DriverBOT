import { Driver } from '../types';

export const drivers: Driver[] = [
  { id: '1', name: 'Philly', username: 'Philly', password: '2025', isActive: true },
  { id: '2', name: 'Morris', username: 'Morris', password: '2025', isActive: true },
  { id: '3', name: 'Jojo', username: 'Jojo', password: '2025', isActive: true },
  { id: '4', name: 'AJ', username: 'AJ', password: '2025', isActive: true },
  { id: '5', name: 'Ike', username: 'Ike', password: '2025', isActive: true },
  { id: '6', name: 'Carsten', username: 'Carsten', password: '2025', isActive: true },
  { id: '7', name: 'Darija', username: 'Darija', password: '2025', isActive: true },
];