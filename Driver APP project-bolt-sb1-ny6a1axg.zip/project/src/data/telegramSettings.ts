import { TelegramSettings } from '../types';

export const defaultTelegramSettings: TelegramSettings = {
  token: '',
  chatId: ''
};