import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Driver, AuthState, LoginRecord } from '../types';
import { useData } from './DataContext';

interface AuthContextType extends AuthState {
  login: (username: string, password: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  isSessionValid: () => boolean;
  loginRecords: LoginRecord[];
  updateLoginRecords: (records: LoginRecord[]) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const { drivers } = useData();
  const [authState, setAuthState] = useState<AuthState>({
    isAuthenticated: false,
    currentDriver: null,
    loginTime: null,
  });

  const [loginRecords, setLoginRecords] = useState<LoginRecord[]>([]);

  // Session timeout (8 hours)
  const SESSION_TIMEOUT = 8 * 60 * 60 * 1000;

  // Load login records from localStorage
  useEffect(() => {
    const savedRecords = localStorage.getItem('loginRecords');
    if (savedRecords) {
      try {
        const records = JSON.parse(savedRecords);
        // Convert date strings back to Date objects
        const recordsWithDates = records.map((record: any) => ({
          ...record,
          loginTime: new Date(record.loginTime),
          logoutTime: record.logoutTime ? new Date(record.logoutTime) : undefined
        }));
        setLoginRecords(recordsWithDates);
      } catch (e) {
        console.error('Error parsing saved login records:', e);
      }
    }
  }, []);

  const updateLoginRecords = (records: LoginRecord[]) => {
    setLoginRecords(records);
    localStorage.setItem('loginRecords', JSON.stringify(records));
  };

  // Load auth state from localStorage on mount
  useEffect(() => {
    const savedAuth = localStorage.getItem('driverAuth');
    if (savedAuth) {
      try {
        const parsed = JSON.parse(savedAuth);
        const loginTime = new Date(parsed.loginTime);
        
        // Check if session is still valid
        if (Date.now() - loginTime.getTime() < SESSION_TIMEOUT) {
          setAuthState({
            isAuthenticated: true,
            currentDriver: parsed.currentDriver,
            loginTime: loginTime,
          });
        } else {
          // Session expired
          localStorage.removeItem('driverAuth');
        }
      } catch (e) {
        console.error('Error parsing saved auth:', e);
        localStorage.removeItem('driverAuth');
      }
    }
  }, []);

  const login = async (username: string, password: string): Promise<{ success: boolean; error?: string }> => {
    console.log('Login attempt:', { username, password });
    
    // Find driver by name (simplified)
    const driver = drivers.find(d => 
      d.name?.toLowerCase() === username.toLowerCase() && 
      d.isActive !== false
    );

    console.log('Found driver:', driver);

    // Check PIN (password should be '2025')
    if (!driver || password !== '2025') {
      return {
        success: false,
        error: 'Invalid name or PIN'
      };
    }

    const loginTime = new Date();
    const today = loginTime.toISOString().split('T')[0]; // YYYY-MM-DD format
    
    // Create login record
    const loginRecord: LoginRecord = {
      id: Date.now().toString(),
      driverId: driver.id,
      driverName: driver.name,
      loginTime,
      date: today
    };
    
    // Add to login records
    const updatedRecords = [...loginRecords, loginRecord];
    updateLoginRecords(updatedRecords);

    const newAuthState: AuthState = {
      isAuthenticated: true,
      currentDriver: driver,
      loginTime,
    };

    setAuthState(newAuthState);
    
    // Save to localStorage
    localStorage.setItem('driverAuth', JSON.stringify(newAuthState));

    return { success: true };
  };

  const logout = () => {
    // Update the current login record with logout time
    if (authState.currentDriver && authState.loginTime) {
      const logoutTime = new Date();
      const updatedRecords = loginRecords.map(record => {
        // Find the most recent login record for this driver without a logout time
        if (record.driverId === authState.currentDriver!.id && 
            !record.logoutTime &&
            Math.abs(record.loginTime.getTime() - authState.loginTime!.getTime()) < 1000) {
          return { ...record, logoutTime };
        }
        return record;
      });
      updateLoginRecords(updatedRecords);
    }

    setAuthState({
      isAuthenticated: false,
      currentDriver: null,
      loginTime: null,
    });
    localStorage.removeItem('driverAuth');
  };

  const isSessionValid = (): boolean => {
    if (!authState.isAuthenticated || !authState.loginTime) {
      return false;
    }

    const timeSinceLogin = Date.now() - authState.loginTime.getTime();
    return timeSinceLogin < SESSION_TIMEOUT;
  };

  // Auto-logout on session timeout
  useEffect(() => {
    if (authState.isAuthenticated && !isSessionValid()) {
      logout();
    }
  }, [authState]);

  const value: AuthContextType = {
    ...authState,
    login,
    logout,
    isSessionValid,
    loginRecords,
    updateLoginRecords,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};