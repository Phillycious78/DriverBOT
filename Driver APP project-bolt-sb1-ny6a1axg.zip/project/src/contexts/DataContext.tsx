import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Driver, CastMember, MessageTemplates, TelegramSettings, SideMission } from '../types';
import { drivers as initialDrivers } from '../data/drivers';
import { castMembers as initialCastMembers } from '../data/castMembers';
import { defaultMessageTemplates } from '../data/messageTemplates';
import { defaultTelegramSettings } from '../data/telegramSettings';
import { defaultSideMissions } from '../data/sideMissions';

interface DataContextType {
  drivers: Driver[];
  castMembers: CastMember[];
  messageTemplates: MessageTemplates;
  telegramSettings: TelegramSettings;
  sideMissions: SideMission[];
  updateDrivers: (drivers: Driver[]) => void;
  updateCastMembers: (castMembers: CastMember[]) => void;
  updateMessageTemplates: (templates: MessageTemplates) => void;
  updateTelegramSettings: (settings: TelegramSettings) => void;
  updateSideMissions: (missions: SideMission[]) => void;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const useData = () => {
  const context = useContext(DataContext);
  if (!context) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};

interface DataProviderProps {
  children: ReactNode;
}

export const DataProvider: React.FC<DataProviderProps> = ({ children }) => {
  const [drivers, setDrivers] = useState<Driver[]>(initialDrivers);
  const [castMembers, setCastMembers] = useState<CastMember[]>(initialCastMembers);
  const [messageTemplates, setMessageTemplates] = useState<MessageTemplates>(defaultMessageTemplates);
  const [telegramSettings, setTelegramSettings] = useState<TelegramSettings>(defaultTelegramSettings);
  const [sideMissions, setSideMissions] = useState<SideMission[]>(defaultSideMissions);

  // Load data from localStorage on mount
  useEffect(() => {
    const savedDrivers = localStorage.getItem('adminDrivers');
    const savedCast = localStorage.getItem('adminCastMembers');
    const savedMessages = localStorage.getItem('adminMessageTemplates');
    const savedTelegram = localStorage.getItem('adminTelegramSettings');
    const savedMissions = localStorage.getItem('adminSideMissions');

    if (savedDrivers) {
      try {
        setDrivers(JSON.parse(savedDrivers));
      } catch (e) {
        console.error('Error parsing saved drivers:', e);
      }
    }
    if (savedCast) {
      try {
        setCastMembers(JSON.parse(savedCast));
      } catch (e) {
        console.error('Error parsing saved cast members:', e);
      }
    }
    if (savedMessages) {
      try {
        setMessageTemplates(JSON.parse(savedMessages));
      } catch (e) {
        console.error('Error parsing saved message templates:', e);
      }
    }
    if (savedTelegram) {
      try {
        setTelegramSettings(JSON.parse(savedTelegram));
      } catch (e) {
        console.error('Error parsing saved telegram settings:', e);
      }
    }
    if (savedMissions) {
      try {
        const missions = JSON.parse(savedMissions);
        // Convert date strings back to Date objects
        const missionsWithDates = missions.map((mission: any) => ({
          ...mission,
          createdAt: new Date(mission.createdAt)
        }));
        setSideMissions(missionsWithDates);
      } catch (e) {
        console.error('Error parsing saved side missions:', e);
      }
    }
  }, []);

  const updateDrivers = (newDrivers: Driver[]) => {
    setDrivers(newDrivers);
    localStorage.setItem('adminDrivers', JSON.stringify(newDrivers));
  };

  const updateCastMembers = (newCastMembers: CastMember[]) => {
    setCastMembers(newCastMembers);
    localStorage.setItem('adminCastMembers', JSON.stringify(newCastMembers));
  };

  const updateMessageTemplates = (newTemplates: MessageTemplates) => {
    setMessageTemplates(newTemplates);
    localStorage.setItem('adminMessageTemplates', JSON.stringify(newTemplates));
  };

  const updateTelegramSettings = (newSettings: TelegramSettings) => {
    setTelegramSettings(newSettings);
    localStorage.setItem('adminTelegramSettings', JSON.stringify(newSettings));
  };

  const updateSideMissions = (newMissions: SideMission[]) => {
    setSideMissions(newMissions);
    localStorage.setItem('adminSideMissions', JSON.stringify(newMissions));
  };

  const value: DataContextType = {
    drivers,
    castMembers,
    messageTemplates,
    telegramSettings,
    sideMissions,
    updateDrivers,
    updateCastMembers,
    updateMessageTemplates,
    updateTelegramSettings,
    updateSideMissions,
  };

  return (
    <DataContext.Provider value={value}>
      {children}
    </DataContext.Provider>
  );
};