import { useState } from 'react';
import { useData } from '../contexts/DataContext';
import { createTelegramService } from '../services/telegramService';
import { createMessages } from '../utils/messageFormatter';
import { Driver, CastMember } from '../types';

interface TelegramHookResult {
  sendTripStarted: (driver: Driver, castMembers: CastMember[], eta: { hours: number; minutes: number }) => Promise<boolean>;
  sendDelayReported: (driver: Driver, delayedCastMembers: CastMember[]) => Promise<boolean>;
  sendFiveMinuteWarning: (driver: Driver, castMembers: CastMember[]) => Promise<boolean>;
  sendDropOffCompleted: (driver: Driver, castMembers: CastMember[]) => Promise<boolean>;
  testConnection: () => Promise<{ success: boolean; error?: string; botInfo?: any }>;
  isLoading: boolean;
  lastError: string | null;
}

export const useTelegram = (): TelegramHookResult => {
  const { messageTemplates, telegramSettings } = useData();
  const [isLoading, setIsLoading] = useState(false);
  const [lastError, setLastError] = useState<string | null>(null);

  const sendMessage = async (messageText: string): Promise<boolean> => {
    if (!telegramSettings.token || !telegramSettings.chatId) {
      setLastError('Telegram not configured. Please check admin settings.');
      return false;
    }

    setIsLoading(true);
    setLastError(null);

    try {
      const telegramService = createTelegramService(
        telegramSettings.token,
        telegramSettings.chatId
      );

      const result = await telegramService.sendMessage(messageText);

      if (!result.success) {
        setLastError(result.error || 'Failed to send message');
        return false;
      }

      return true;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      setLastError(errorMessage);
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const sendTripStarted = async (
    driver: Driver,
    castMembers: CastMember[],
    eta: { hours: number; minutes: number }
  ): Promise<boolean> => {
    const message = createMessages.tripStarted(messageTemplates, driver, castMembers, eta);
    return sendMessage(message);
  };

  const sendDelayReported = async (
    driver: Driver,
    delayedCastMembers: CastMember[]
  ): Promise<boolean> => {
    const message = createMessages.delayReported(messageTemplates, driver, delayedCastMembers);
    return sendMessage(message);
  };

  const sendFiveMinuteWarning = async (
    driver: Driver,
    castMembers: CastMember[]
  ): Promise<boolean> => {
    const message = createMessages.fiveMinuteWarning(messageTemplates, driver, castMembers);
    return sendMessage(message);
  };

  const sendDropOffCompleted = async (
    driver: Driver,
    castMembers: CastMember[]
  ): Promise<boolean> => {
    const message = createMessages.dropOffCompleted(messageTemplates, driver, castMembers);
    return sendMessage(message);
  };

  const testConnection = async (): Promise<{ success: boolean; error?: string; botInfo?: any }> => {
    if (!telegramSettings.token) {
      return {
        success: false,
        error: 'Bot token not configured'
      };
    }

    setIsLoading(true);
    setLastError(null);

    try {
      const telegramService = createTelegramService(
        telegramSettings.token,
        telegramSettings.chatId
      );

      const result = await telegramService.testConnection();
      
      if (!result.success) {
        setLastError(result.error || 'Connection test failed');
      }

      return result;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      setLastError(errorMessage);
      return {
        success: false,
        error: errorMessage
      };
    } finally {
      setIsLoading(false);
    }
  };

  return {
    sendTripStarted,
    sendDelayReported,
    sendFiveMinuteWarning,
    sendDropOffCompleted,
    testConnection,
    isLoading,
    lastError
  };
};